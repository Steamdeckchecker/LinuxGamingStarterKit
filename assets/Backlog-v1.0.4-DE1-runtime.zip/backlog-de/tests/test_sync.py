"""Offline regression checks for the 1.0.4 update; uses a temporary Steam library."""
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, bytes):
        path.write_bytes(data)
    else:
        path.write_text(data, encoding='utf-8')


class SyncUpdateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='backlog-test-')
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.steam = self.base / 'Steam'
        self.user = self.steam / 'userdata/123'
        self.target = self.base / 'installed'
        self.cache = self.user / 'config/librarycache'
        self.shortcut_id = 3000000123
        self.config = "window.BACKLOG_CONFIG = {scenes: ['ripple'], shuffle: false, minutesPerScene: 10, clock: {hour12: true}};\n"
        write(self.target / 'config.js', self.config)
        self.local_config()
        for aid in (10, 20):
            write(self.steam / ('steamapps/appmanifest_%d.acf' % aid),
                  '"AppState" { "appid" "%d" "name" "Game %d" }' % (aid, aid))
            write(self.steam / ('appcache/librarycache/%d_library_600x900.jpg' % aid), b'fixture art')
        # One non-Steam shortcut, with a 32-bit app id and local playtime.
        shortcut = (b'\x00shortcuts\x00\x000\x00\x02appid\x00' + struct.pack('<I', self.shortcut_id)
                    + b'\x01AppName\x00Shortcut\x00\x08\x08')
        write(self.user / 'config/shortcuts.vdf', shortcut)
        for aid in (10, 20, self.shortcut_id):
            write(self.user / ('760/remote/%d/screenshots/20261121120000_1.jpg' % aid), b'fixture shot')
        self.summary(1, 10, 100)
        self.per_game(4, 10, 200)
        self.cloud_hidden([20])

    def local_config(self, hidden=()):
        collections = json.dumps({'hidden': {'added': list(hidden), 'removed': []}})
        text = ('"UserLocalConfigStore" { "Software" { "Valve" { "Steam" { "apps" {'
                ' "10" { "Playtime" "150" "LastPlayed" "1000" }'
                ' "20" { "Playtime" "60" "LastPlayed" "900" }'
                ' "%d" { "Playtime" "30" "LastPlayed" "800" }'
                ' } } } } "user-collections" %s }') % (self.shortcut_id, json.dumps(collections))
        write(self.user / 'config/localconfig.vdf', text)

    def cloud_hidden(self, added, removed=(), deleted=False):
        entry = {'value': json.dumps({'added': list(added), 'removed': list(removed)}), 'is_deleted': deleted}
        write(self.user / 'config/cloudstorage/cloud-storage-namespace-1.json',
              json.dumps([['user-collections.hidden', entry]]))

    def summary(self, unlocked, total, stamp):
        write(self.cache / 'achievement_progress.json', json.dumps({
            'mapCache': [[10, {'unlocked': unlocked, 'total': total, 'cache_time': stamp}]]}))

    def per_game(self, unlocked, total, stamp):
        path = self.cache / '10.json'
        write(path, json.dumps([['achievements', {'version': 1, 'data': {'nTotal': total, 'nAchieved': unlocked}}]]))
        os.utime(path, (stamp, stamp))

    def sync(self):
        env = dict(os.environ, STEAM_API_KEY='', APPDATA=str(self.base / 'appdata'),
                   XDG_CONFIG_HOME=str(self.base / 'config'))
        result = subprocess.run([
            sys.executable, str(ROOT / 'tools/sync.py'), '--install', '--no-schedule',
            '--steam', str(self.steam), '--target', str(self.target)],
            env=env, capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        text = (self.target / 'library/library.js').read_text()
        return json.loads(text.split('window.BACKLOG_LIBRARY = ', 1)[1].rstrip(';\n'))

    def test_update_preserves_existing_configuration_and_german_ui(self):
        self.sync()
        self.assertEqual((self.target / 'config.js').read_text(), self.config)
        self.assertIn(' Stunden', (self.target / 'core.js').read_text())
        self.assertIn('lang="de"', (self.target / 'index.html').read_text())

    def test_hidden_games_and_screenshots_are_removed_from_existing_install(self):
        write(self.target / 'config.js', self.config.replace('scenes:', 'library: {showHidden: true}, scenes:'))
        self.sync()
        self.assertTrue((self.target / 'library/20').is_dir())
        write(self.target / 'config.js', self.config)
        data = self.sync()
        self.assertEqual({g['appid'] for g in data['games']}, {10, self.shortcut_id})
        self.assertNotIn(20, {s['appid'] for s in data['screenshots']})
        self.assertFalse((self.target / 'library/20').exists())
        self.assertFalse(list((self.target / 'library/shots').glob('20_*')))

    def test_show_hidden_opt_in_restores_games_and_screenshots(self):
        write(self.target / 'config.js', self.config.replace('scenes:', 'library: {showHidden: true}, scenes:'))
        data = self.sync()
        self.assertEqual({g['appid'] for g in data['games']}, {10, 20, self.shortcut_id})
        self.assertIn(20, {s['appid'] for s in data['screenshots']})

    def test_non_steam_hidden_collection_normalizes_64_bit_game_id(self):
        self.local_config([(self.shortcut_id << 32) | 0x02000000])
        data = self.sync()
        self.assertEqual([g['appid'] for g in data['games']], [10])
        self.assertEqual({s['appid'] for s in data['screenshots']}, {10})

    def test_removed_or_deleted_hidden_collection_does_not_hide_game(self):
        for removed, deleted in (([20], False), ([], True)):
            with self.subTest(removed=removed, deleted=deleted):
                self.cloud_hidden([20], removed, deleted)
                self.assertIn(20, {g['appid'] for g in self.sync()['games']})

    def test_newer_per_game_achievements_replace_summary(self):
        game = next(g for g in self.sync()['games'] if g['appid'] == 10)
        self.assertEqual(game['achievements'], {'unlocked': 4, 'total': 10})

    def test_newer_summary_wins_over_older_per_game_cache(self):
        self.summary(7, 10, 300)
        game = next(g for g in self.sync()['games'] if g['appid'] == 10)
        self.assertEqual(game['achievements'], {'unlocked': 7, 'total': 10})

    def test_invalid_per_game_cache_uses_summary(self):
        write(self.cache / '10.json', 'broken JSON')
        game = next(g for g in self.sync()['games'] if g['appid'] == 10)
        self.assertEqual(game['achievements'], {'unlocked': 1, 'total': 10})

    def test_achievements_work_without_summary_and_are_clamped(self):
        (self.cache / 'achievement_progress.json').unlink()
        self.per_game(12, 10, 200)
        game = next(g for g in self.sync()['games'] if g['appid'] == 10)
        self.assertEqual(game['achievements'], {'unlocked': 10, 'total': 10})


if __name__ == '__main__':
    unittest.main()

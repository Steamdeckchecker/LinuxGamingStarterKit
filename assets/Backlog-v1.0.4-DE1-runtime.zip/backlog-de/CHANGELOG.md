# Änderungen

## 1.0.4-DE1 – 22. November 2026

Aktualisierung der deutschen Ausgabe auf Backlog v1.0.4 von Glidian (Commit `868b5a02aefae5b5b9efb2f15e9b88c037c70e5c`). Enthält auch die Änderungen aus v1.0.3.

- Zuverlässigere Erfolgserkennung unter Linux und Windows: Zusätzlich zu Steams Übersicht wird der Cache pro Spiel gelesen und der neuere Stand verwendet.
- In Steam ausgeblendete Steam- und Nicht-Steam-Spiele werden samt Screenshots standardmäßig ausgelassen.
- Neue Option `library.showHidden: true`, um diese Spiele bewusst wieder anzuzeigen; wirksam ab der nächsten Datenaktualisierung.
- Bestehende Konfigurationen bleiben erhalten. Auch ohne die neue Option werden versteckte Spiele ausgelassen.
- Deutsche Anzeigen und KDE-Installationsdialoge, 24-Stunden-Standard und automatischer Shuffle bleiben erhalten.
- Deutsche Anleitungen und englische Originaldokumentation aktualisiert.
- Neun automatische Integrationstests mit einer temporären Steam-Bibliothek für Erfolge, versteckte Steam- und Nicht-Steam-Spiele, Screenshot-Bereinigung und die Übernahme bestehender Einstellungen.

Prüfung: Alle neun Tests sowie JavaScript-, Python- und Shell-Syntax erfolgreich. Tests im Steam-Spielmodus auf echter Hardware und ein Windows-Laufzeittest stehen noch aus.

## 1.0.2-DE1 – 19. November 2026

Erste deutsche Ausgabe auf Basis von Backlog v1.0.2 von Glidian.

- Deutsche Datumsanzeigen, Wochentage und Monate.
- Deutsche Spielzeit-, Bibliotheks-, Erfolgs- und Rangbeschriftungen in allen Szenen.
- Deutsches Dezimalkomma und Tausenderpunkt bei Spielstunden.
- 24-Stunden-Uhr als Standard bei neuen Installationen; bestehende Einstellungen bleiben erhalten.
- Deutsche Installations- und Deinstallationsdialoge unter KDE / Steam Deck.
- Deutsche Schreibweise und Zeilenumbrüche für längere Beschriftungen.
- Deutsche README und Installationsanleitung, einschließlich des vorhandenen automatischen Shuffle-Modus.

Technisch geprüft: JavaScript- und Shell-Syntax, Text- und Datumsfunktionen sowie Neuinstallation und Übernahme vorhandener Einstellungen in einem temporären Ordner.
Ein visueller Browser-Test und ein Test im Steam-Spielmodus auf echter Hardware stehen noch aus.

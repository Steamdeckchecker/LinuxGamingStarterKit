# Backlog German

**Ein Bildschirmschoner für Steam Deck und Steam Big Picture – mit deutschen Bildschirmanzeigen.**

Deine Spielecover, Spielstunden und Erfolge werden zusammen mit Uhrzeit und Datum in vier animierten Szenen angezeigt. Der automatische Shuffle wechselt zwischen den ausgewählten Szenen. Kostenlos und quelloffen unter der MIT-Lizenz.

Dies ist die **inoffizielle deutsche Version von [Backlog](https://github.com/glidiandev/backlog)**, entwickelt von **Glidian**. Die deutsche Anpassung wird in diesem Fork von **Steam Deck Checker** bereitgestellt. Aktuelle deutsche Version: **1.0.4-DE1**.

**[Deutsche Version herunterladen](https://github.com/Steamdeckchecker/backlog-german/releases/latest)** · [Kurzanleitung](LIESMICH-DE.md) · [Änderungen](CHANGELOG.md) · [Englische Originaldokumentation](README.en.md)

## Neu in 1.0.4-DE1

- **Zuverlässigere Erfolge:** Backlog berücksichtigt zusätzlich Steams Cache pro Spiel und übernimmt den neueren Stand. Falls Erfolge fehlen, die Bibliotheksseite des Spiels einmal in Steam öffnen und die nächste Aktualisierung abwarten.
- **Ausgeblendete Spiele bleiben verborgen:** In Steam versteckte Steam- und Nicht-Steam-Spiele samt Screenshots werden standardmäßig ausgelassen.
- **Einstellungen bleiben erhalten:** Die vorhandene `config.js`, deine Szenenauswahl und der automatische Shuffle werden weiterverwendet.

## Das ist auf Deutsch

- Deutsche Wochentags- und Monatskürzel im Datum, zum Beispiel **SO, 22. NOV**.
- Spielanzahl und Spielstunden mit deutschen Zahlenformaten: **2,5 Stunden** und **1.235 Stunden**.
- Angaben wie **Zuletzt gespielt: vor 3 Tagen** oder **gestern**.
- Erfolge, vollständig freigeschaltete Erfolge und Rangbeschriftungen.
- Installations- und Deinstallationsdialoge auf dem Steam Deck und anderen KDE-Desktops.
- Neue Installationen verwenden standardmäßig eine **24-Stunden-Uhr**.

Die Übersetzung gilt für alle vier Hauptszenen und die optionale Szene **Ripple 2**. Deutsche Groß- und Kleinschreibung bleibt in den Spielzeitangaben erhalten; längere Texte können umbrechen. Spielnamen und Cover werden aus Steam übernommen. Die technischen Terminalmeldungen der Synchronisationsprogramme bleiben auf Englisch.

## Die Szenen

| Szene | Darstellung |
| --- | --- |
| **Mosaik** (`mosaic`) | Viele kleine Spielecover setzen sich zum großen Motiv eines Spiels zusammen. Die Kamera fährt hinein und wieder heraus. |
| **Drift** (`drift`) | Eine geneigte Coverwand gleitet vorbei und hebt einzelne Spiele hervor. |
| **Flip** (`flip`) | Eine Covertafel klappt ihre Felder ähnlich einer mechanischen Anzeigetafel um. |
| **Wellen** (`ripple`) | Eine langsame Welle läuft durch ein Raster aus Spielecovern. |
| **Ripple 2** (`ripple2`, optional) | Eine zusätzliche Variante von Wellen mit stärkerer Bewegung. |

![Beispiel der Drift-Szene aus dem Originalprojekt](docs/drift.jpg)

*Das Beispielbild stammt aus dem Originalprojekt und zeigt dessen englische Texte. In diesem Fork sind die Bildschirmanzeigen auf Deutsch.*

## Installation auf Steam Deck / SteamOS

1. Die ZIP-Datei **Backlog-v1.0.4-DE1.zip** unter [Releases](https://github.com/Steamdeckchecker/backlog-german/releases/latest) herunterladen.
2. In den **Desktop-Modus** wechseln und die ZIP-Datei vollständig entpacken.
3. Im Ordner `backlog-de` **Install Backlog.desktop** doppelklicken. Je nach Dateimanager wird die Datei als **Backlog installieren** angezeigt. Falls nachgefragt wird, die Ausführung bestätigen.
4. Szenen, Anzeigedauer und Umfang der Uhranzeige auswählen.
5. In den **Spielmodus** zurückkehren und unter **Einstellungen > Anpassung > Bildschirmschoner** den Eintrag **backlog** auswählen. Falls er fehlt, Steam neu starten.

Es ist kein Kompilieren erforderlich. Der Installer benötigt Python 3, das unter SteamOS normalerweise bereits vorhanden ist.

**Bereits installiert?** Die deutsche Version einfach erneut installieren. Die vorhandene `config.js` bleibt erhalten. Szenen, Dauer und Uhranzeige werden aktualisiert, wenn du sie im Installer auswählst. Eine vorherige Deinstallation ist nicht nötig.

Alternativ im entpackten Ordner ein Terminal öffnen und ausführen:

```sh
sh tools/install.sh
```

## Automatischer Shuffle und Anzeigedauer

Der zufällige Szenenwechsel ist **standardmäßig aktiviert**. Jede der vier Hauptszenen läuft zunächst **fünf Minuten**. Alle gewählten Szenen werden in zufälliger Reihenfolge angezeigt; bei mehreren Szenen folgt dieselbe Szene nicht unmittelbar auf sich selbst.

Anzeigedauer und Szenenauswahl kannst du jederzeit mit **Backlog installieren** ändern. Alternativ die **installierte** `config.js` bearbeiten:

```js
scenes: ['mosaic', 'drift', 'flip', 'ripple'],
shuffle: true,
minutesPerScene: 5,
```

- `shuffle: true` aktiviert die zufällige Reihenfolge; `false` verwendet die angegebene Reihenfolge.
- `minutesPerScene: 1` wechselt jede Minute, `10` alle zehn Minuten.
- Für die zusätzliche Szene `ripple2` diese ID in die Liste aufnehmen.

Die installierte Konfiguration liegt unter:

```text
<Steam>/config/uioverrides/screensavers/backlog/config.js
```

Nach einer Änderung den Bildschirmschoner neu öffnen. Wurde eine ältere Konfiguration mit `hour12: true` übernommen, bleibt deren 12-Stunden-Uhr erhalten; die Zusätze erscheinen als „vorm.“ und „nachm.“. Für 24 Stunden den Wert auf `hour12: false` ändern.

## Windows / Steam Big Picture

Die ZIP-Datei vollständig entpacken und im entpackten Ordner PowerShell öffnen:

```powershell
powershell -ExecutionPolicy Bypass -File tools\sync.ps1 -Install
```

Danach in Steam **Big Picture** öffnen und unter **Einstellungen > Anpassung > Bildschirmschoner** den Eintrag **backlog** auswählen. Falls nötig, Steam neu starten.

Beispiel für zwei Szenen mit jeweils zehn Minuten:

```powershell
powershell -ExecutionPolicy Bypass -File tools\sync.ps1 -Install -Scenes mosaic,drift -Minutes 10
```

Mit `-Clock all`, `-Clock clock` oder `-Clock none` werden alle Angaben, nur Uhrzeit und Datum oder keine Uhranzeige eingeblendet.

## Linux / Bazzite

Im entpackten Ordner `sh tools/install.sh` ausführen und **backlog** in Steam Big Picture beziehungsweise im Spielmodus auswählen. Python 3 wird benötigt. Auf KDE-Desktops ist auch der grafische Starter nutzbar.

```sh
sh tools/install.sh --scenes mosaic,drift --minutes 10 --clock all
```

## Weitere Einstellungen

| Einstellung in `config.js` | Funktion |
| --- | --- |
| `clock.show` | `'all'`: Uhrzeit, Datum und Bibliotheksdaten; `'clock'`: nur Uhrzeit und Datum; `'none'`: keine Uhranzeige. |
| `featured` | Bestimmte Spiele bevorzugt hervorheben und für die Mosaikmotive nutzen. |
| `library.exclude` | Spiele anhand von Name oder App-ID ausblenden. |
| `library.showHidden` | In Steam ausgeblendete Spiele samt Screenshots ebenfalls auslassen (Standard). Mit `true` ab der nächsten Datenaktualisierung wieder anzeigen. |
| `library.minMinutes` | Spiele mit weniger als der angegebenen Spielzeit auslassen. `1` zeigt nur bereits gespielte Spiele. |
| `library.merge` | Mehrere Einträge zusammenfassen und ihre Spielzeit addieren. Gleiche Namen werden automatisch zusammengeführt. |
| `extraGames` | Eigene Spiele mit eigenen Bildern ergänzen. |
| `oled` | Pixelverschiebung, nächtliche Abdunklung und eine optionale Schwarzblende einstellen. |

Die vollständige technische Dokumentation der Installations- und Synchronisationsoptionen steht in [tools/README.md](tools/README.md), weitere Originalhinweise in [README.en.md](README.en.md).

## Spieledaten und Datenschutz

Backlog übernimmt lokal gespeicherte Steam-Daten: Spiele, Spielzeit, Erfolge, Cover und neueste Screenshots. Auch Nicht-Steam-Spiele mit eigenen Bildern oder Spielzeit können enthalten sein. Es ist kein zusätzlicher Account erforderlich; es gibt kein Tracking.

Unter SteamOS und anderen Linux-Systemen mit systemd aktualisiert der Installer die lokalen Spieledaten alle 15 Minuten und nach einem Neustart. Dafür wird eine Kopie des Synchronisationsprogramms im Benutzerverzeichnis gespeichert. Der Download-Ordner kann danach gelöscht werden. Unter Windows lässt sich die tägliche Aktualisierung mit `tools\sync.ps1 -ScheduleDaily` einrichten.

Optional kann ein eigener Steam-Web-API-Schlüssel verwendet werden, um Spielstunden von mehreren Geräten abzurufen. Diese ausdrücklich aktivierte Option benötigt eine Netzwerkverbindung; Details stehen in [tools/README.md](tools/README.md).

## Deinstallation

Auf Steam Deck / KDE **Uninstall Backlog.desktop** beziehungsweise **Backlog deinstallieren** starten. Alternativ:

```sh
python3 ~/.local/share/backlog/sync.py --uninstall
```

Unter Windows eine eingerichtete Aufgabe mit `tools\sync.ps1 -Unschedule` entfernen und den Ordner `<Steam>\config\uioverrides\screensavers\backlog` löschen.

## Prüfstand der deutschen Version

Neun automatische Tests mit einer temporären Steam-Testbibliothek prüfen die neue Erfolgserkennung, das Auslassen und Wiedereinblenden versteckter Steam- und Nicht-Steam-Spiele samt Screenshots sowie die Übernahme einer vorhandenen Konfiguration. JavaScript-, Python- und Shell-Syntax wurden ebenfalls geprüft.

Die Tests lassen sich im Quellcode mit `python3 -m unittest discover -s tests -v` ausführen. Ein Test der deutschen Version im Steam-Spielmodus auf echter Hardware steht noch aus. Die Windows-Synchronisation wurde aus dem Original übernommen; ein Windows-Laufzeittest steht ebenfalls aus.

## Urheber und Lizenz

- **Original:** [Backlog von Glidian](https://github.com/glidiandev/backlog), [glidian.dev](https://glidian.dev).
- **Deutscher Fork:** [Steam Deck Checker](https://www.youtube.com/@SteamDeckChecker).
- **Grundlage:** Backlog v1.0.4; die Original-Entwicklungshistorie und Lizenz bleiben erhalten.
- **Lizenz:** [MIT](LICENSE). Die Schriftlizenzen von Archivo, Inter, Barlow Condensed und Share Tech Mono liegen unter `backlog/fonts/`.

Backlog ist ein unabhängiges Fanprojekt. Spielenamen, Cover und andere Spielgrafiken gehören ihren jeweiligen Rechteinhabern. Es besteht keine Verbindung zu Valve oder den Spieleherstellern.

import QtQuick
import QtWebEngine

WebEngineView {
    id: view
    property var options: ({})
    property bool animationPaused: false
    property bool pageReady: false
    property string failure: ""
    property var latestPointer: null

    url: Qt.resolvedUrl("../web/index.html")
    backgroundColor: "#070a10"
    enabled: false // Desktop icons, selection and right-click stay with Plasma.
    audioMuted: true
    settings.showScrollBars: false
    settings.localContentCanAccessFileUrls: true
    settings.localContentCanAccessRemoteUrls: false
    settings.navigateOnDropEnabled: false
    settings.localStorageEnabled: false

    function sendOptions() {
        if (!pageReady) return;
        const config = Object.assign({}, options, {paused: animationPaused});
        runJavaScript("window.LiveWallpaper && window.LiveWallpaper.configure(" + JSON.stringify(config) + ")");
    }
    function setPointer(x, y, down, active) {
        latestPointer = active ? {x: x, y: y, down: down, free: true} : null;
        sendPointer();
    }
    function sendPointer() {
        if (!pageReady || animationPaused) return;
        runJavaScript("window.LiveWallpaper && window.LiveWallpaper.setPointer(" + JSON.stringify(latestPointer) + ")");
    }
    function clearPointer() {
        latestPointer = null;
        if (pageReady) runJavaScript("window.LiveWallpaper && window.LiveWallpaper.clearPointer()");
    }
    onOptionsChanged: sendOptions()
    onAnimationPausedChanged: {
        sendOptions();
        if (animationPaused) clearPointer();
        else sendPointer();
    }
    onLoadingChanged: function(info) {
        if (info.status === WebEngineView.LoadSucceededStatus) {
            pageReady = true;
            failure = "";
            sendOptions();
            sendPointer();
        } else if (info.status === WebEngineView.LoadFailedStatus) {
            pageReady = false;
            failure = "Die Animation konnte nicht geladen werden: " + info.errorString;
        }
    }
    onRenderProcessTerminated: function(status, exitCode) {
        pageReady = false;
        failure = "Die Hintergrundwiedergabe wurde beendet (Code " + exitCode + "). Bitte den Hintergrund neu auswählen.";
    }
}

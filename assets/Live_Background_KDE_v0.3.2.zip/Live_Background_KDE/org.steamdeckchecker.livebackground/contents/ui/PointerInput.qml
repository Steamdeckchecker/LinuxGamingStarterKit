pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Window

// Folder View is stacked above the wallpaper and accepts hover and presses.
// Observe presses from a transparent item at the top of this desktop window.
// Observe hover on the common ancestor: a hover-enabled sibling would block
// Folder View's own hover delivery even with blocking:false (Qt's legacy rule).
// Neither handler takes an exclusive grab. No global input is captured.
Item {
    id: root
    required property Item surface
    parent: surface.Window.window ? surface.Window.window.contentItem : surface
    anchors.fill: parent
    z: 1000000
    visible: surface.visible
    signal pointerUpdated(real x, real y, bool down, bool present)
    signal pointerCanceled()
    property real lastX: 0
    property real lastY: 0
    property bool lastPresent: false
    property bool touchMode: false
    property var hover: null

    function publish() {
        let position;
        let down = false;
        if (contact.active) {
            position = contact.point.position;
            down = true;
        } else if (!touchMode && mousePress.active) {
            position = mousePress.point.position;
            down = true;
        } else if (!touchMode && hover && hover.hovered) {
            position = hover.point.position;
        } else {
            lastPresent = false;
            pointerUpdated(lastX, lastY, false, false);
            return;
        }
        const local = surface.mapFromItem(root, position.x, position.y);
        if (!surface.contains(local)) {
            lastPresent = false;
            pointerUpdated(lastX, lastY, false, false);
            return;
        }
        lastX = local.x;
        lastY = local.y;
        lastPresent = true;
        pointerUpdated(lastX, lastY, down, true);
    }

    onVisibleChanged: { if (!visible) pointerCanceled(); }

    // A PointerHandler's parent property also changes its QObject owner.
    // Create/destroy this one explicitly so changing wallpaper removes the
    // observer attached to the window, rather than leaking it in plasmashell.
    Component.onCompleted: hover = hoverComponent.createObject(root)
    Component.onDestruction: {
        if (hover) {
            hover.enabled = false;
            hover.destroy();
        }
    }
    Component {
        id: hoverComponent
        HoverHandler {
            parent: root.parent
            enabled: root.visible
            blocking: false
            acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad | PointerDevice.Stylus | PointerDevice.Airbrush
            onPointChanged: {
                if (!contact.active && hovered) root.touchMode = false;
                root.publish();
            }
            onHoveredChanged: root.publish()
        }
    }
    PointHandler {
        id: mousePress
        target: null
        acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad | PointerDevice.Stylus | PointerDevice.Airbrush
        acceptedButtons: Qt.LeftButton
        onActiveChanged: {
            if (active) {
                root.touchMode = false;
                root.publish();
            } else if (!root.touchMode) {
                // HoverHandler's point can still be the pre-drag position.
                root.pointerUpdated(root.lastX, root.lastY, false, root.lastPresent && root.hover && root.hover.hovered);
            }
        }
        onPointChanged: { if (active) root.publish(); }
        onCanceled: root.pointerCanceled()
    }
    PointHandler {
        id: contact
        target: null
        acceptedDevices: PointerDevice.TouchScreen
        // Avoid synthesized mouse events interrupting a real touch sequence.
        acceptedButtons: Qt.NoButton
        onActiveChanged: {
            if (active) root.touchMode = true;
            root.publish();
        }
        onPointChanged: root.publish()
        onCanceled: root.pointerCanceled()
    }
}

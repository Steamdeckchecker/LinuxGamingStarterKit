import QtQuick

// Plasma owns the desktop's interval. It must not depend on Chromium's
// visibility heuristics or throttling of background JavaScript timers.
QtObject {
    id: root
    property string selection: "matrix"
    property int minutes: 5
    property bool paused: false
    readonly property string theme: currentTheme
    readonly property bool randomEnabled: selection === "random"
    readonly property int intervalMs: Math.round(Math.min(30, Math.max(1, minutes))) * 60000

    readonly property var themes: ["matrix", "code", "storm", "starfield", "fireflies", "neon", "neon-bazzite", "orbs", "orbs-bazzite"]
    property string currentTheme: "matrix"
    property var bag: []
    property int remainingMs: intervalMs
    property double dueMs: 0
    property bool ready: false

    function stop(preserve) {
        if (countdown.running && preserve) {
            remainingMs = Math.max(1, dueMs - Date.now());
        }
        countdown.stop();
        dueMs = 0;
    }

    function start() {
        if (!ready || selection !== "random" || paused || countdown.running) return;
        countdown.interval = remainingMs;
        dueMs = Date.now() + remainingMs;
        countdown.start();
    }

    function choose() {
        let next = bag.slice();
        if (next.length === 0) {
            next = themes.slice();
            for (let i = next.length - 1; i > 0; --i) {
                const j = Math.floor(Math.random() * (i + 1));
                const swap = next[i];
                next[i] = next[j];
                next[j] = swap;
            }
            const last = next.length - 1;
            if (last > 0 && next[last] === currentTheme) {
                const swap = next[0];
                next[0] = next[last];
                next[last] = swap;
            }
        }
        currentTheme = next.pop();
        bag = next;
    }

    function resetSelection() {
        if (!ready) return;
        stop(false);
        remainingMs = intervalMs;
        bag = [];
        if (selection === "random") choose();
        else currentTheme = themes.indexOf(selection) >= 0 ? selection : "matrix";
        start();
    }

    onSelectionChanged: resetSelection()
    onIntervalMsChanged: {
        if (!ready) return;
        stop(false);
        remainingMs = intervalMs;
        start();
    }
    onPausedChanged: {
        if (paused) stop(true);
        else start();
    }
    Component.onCompleted: {
        ready = true;
        resetSelection();
    }

    property Timer countdown: Timer {
        repeat: false
        onTriggered: {
            root.dueMs = 0;
            root.remainingMs = root.intervalMs;
            if (root.selection !== "random" || root.paused) return;
            root.choose();
            root.start();
        }
    }
}

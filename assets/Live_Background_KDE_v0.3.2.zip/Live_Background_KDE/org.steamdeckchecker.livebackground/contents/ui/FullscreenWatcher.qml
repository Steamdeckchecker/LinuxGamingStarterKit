import QtQuick
import org.kde.taskmanager as TaskManager

Item {
    id: root
    property bool obscured: false

    function update() {
        let found = false;
        for (let i = 0; i < windows.count; ++i) {
            const entry = windows.objectAt(i);
            if (entry && entry.fullScreen && !entry.minimized) {
                found = true;
                break;
            }
        }
        obscured = found;
    }

    TaskManager.VirtualDesktopInfo { id: desktopInfo }
    TaskManager.ActivityInfo { id: activityInfo }
    TaskManager.TasksModel {
        id: tasks
        groupMode: TaskManager.TasksModel.GroupDisabled
        filterByVirtualDesktop: true
        virtualDesktop: desktopInfo.currentDesktop
        filterByActivity: true
        activity: activityInfo.currentActivity
    }
    Instantiator {
        id: windows
        model: tasks
        delegate: QtObject {
            required property var model
            property bool fullScreen: model.IsFullScreen === true
            property bool minimized: model.IsMinimized === true
            onFullScreenChanged: Qt.callLater(root.update)
            onMinimizedChanged: Qt.callLater(root.update)
        }
        onObjectAdded: function(index, object) { Qt.callLater(root.update); }
        onObjectRemoved: function(index, object) { Qt.callLater(root.update); }
    }
}

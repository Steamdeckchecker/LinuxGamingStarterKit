import QtQuick
import QtQuick.Controls as Controls
import org.kde.plasma.plasmoid

WallpaperItem {
    id: root
    readonly property bool paused: configuration.Paused || !visible || (configuration.PauseFullscreen && fullscreen.obscured)
    readonly property var options: ({
        theme: rotation.theme,
        randomMinutes: configuration.RandomMinutes,
        speed: configuration.Speed,
        fps: configuration.Fps,
        quality: configuration.Quality / 100,
        logo: configuration.LogoPath,
        bazziteLogo: configuration.BazziteLogoPath,
        wallpaper: configuration.WallpaperPath,
        bazziteWallpaper: configuration.BazziteWallpaperPath,
        dim: configuration.Dim
    })

    Rectangle { anchors.fill: parent; color: "#070a10" }
    FullscreenWatcher { id: fullscreen }
    ThemeRotation {
        id: rotation
        selection: root.configuration.Theme
        minutes: root.configuration.RandomMinutes
        paused: root.paused || player.status !== Loader.Ready
            || !player.item.pageReady || player.item.failure.length > 0
    }
    Loader {
        id: player
        anchors.fill: parent
        source: "WebWallpaper.qml"
    }
    Binding {
        target: player.item
        property: "options"
        value: root.options
        when: player.status === Loader.Ready
    }
    Binding {
        target: player.item
        property: "animationPaused"
        value: root.paused
        when: player.status === Loader.Ready
    }

    PointerInput {
        surface: root
        onPointerUpdated: function(x, y, down, present) {
            if (player.status === Loader.Ready) player.item.setPointer(x, y, down, present);
        }
        onPointerCanceled: {
            if (player.status === Loader.Ready) player.item.clearPointer();
        }
    }
    Controls.Label {
        anchors.centerIn: parent
        width: Math.min(parent.width - 48, 640)
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        color: "#e5e9f0"
        visible: player.status === Loader.Error || (player.item !== null && player.item.failure.length > 0)
        text: player.status === Loader.Error
            ? "Live Background: QtWebEngine konnte nicht geladen werden. Bitte install.sh im Terminal ausführen und dessen Diagnose prüfen."
            : (player.item ? player.item.failure : "")
    }
}

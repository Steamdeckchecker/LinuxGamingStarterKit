import QtQuick
import QtQuick.Controls as Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import org.kde.kirigami as Kirigami

Kirigami.FormLayout {
    id: root
    property alias formLayout: root
    // Plasma injects these when it creates a wallpaper's settings page.
    property var configDialog
    property var wallpaperConfiguration
    signal configurationChanged()
    property string cfg_Theme: "matrix"
    property int cfg_RandomMinutes: 5
    property real cfg_Speed: 1.0
    property int cfg_Fps: 24
    property int cfg_Quality: 60
    property bool cfg_Paused: false
    property bool cfg_PauseFullscreen: true
    property string cfg_LogoPath: ""
    property string cfg_BazziteLogoPath: ""
    property string cfg_WallpaperPath: ""
    property string cfg_BazziteWallpaperPath: ""
    property int cfg_Dim: 45

    // Also notify Plasma versions that do not automatically watch cfg_*.
    // Keep one notification per config key, including interval-only edits.
    onCfg_ThemeChanged: configurationChanged()
    onCfg_RandomMinutesChanged: configurationChanged()
    onCfg_SpeedChanged: configurationChanged()
    onCfg_FpsChanged: configurationChanged()
    onCfg_QualityChanged: configurationChanged()
    onCfg_PausedChanged: configurationChanged()
    onCfg_PauseFullscreenChanged: configurationChanged()
    onCfg_LogoPathChanged: configurationChanged()
    onCfg_BazziteLogoPathChanged: configurationChanged()
    onCfg_WallpaperPathChanged: configurationChanged()
    onCfg_BazziteWallpaperPathChanged: configurationChanged()
    onCfg_DimChanged: configurationChanged()

    readonly property var themeIds: ["matrix", "code", "storm", "starfield", "fireflies", "neon", "neon-bazzite", "orbs", "orbs-bazzite", "random"]

    Controls.ComboBox {
        Kirigami.FormData.label: "Motiv:"
        model: ["Matrix-Regen", "Code-Stream", "Gewitter", "Sternenfeld", "Glühwürmchen", "Neon-Emblem-SDC", "Neon-Emblem-Bazzite", "Schwebende Blasen SDC", "Schwebende Blasen Bazzite", "Zufällig (automatischer Wechsel)"]
        currentIndex: Math.max(0, root.themeIds.indexOf(root.cfg_Theme))
        onActivated: root.cfg_Theme = root.themeIds[currentIndex]
    }
    Controls.SpinBox {
        id: randomMinutesInput
        objectName: "randomMinutes"
        Kirigami.FormData.label: "Zufallswechsel alle (Minuten):"
        from: 1; to: 30
        editable: true
        live: true
        value: root.cfg_RandomMinutes
        enabled: root.cfg_Theme === "random"
        onValueChanged: root.cfg_RandomMinutes = value
    }
    Controls.SpinBox {
        Kirigami.FormData.label: "Geschwindigkeit (%):"
        from: 25; to: 300; stepSize: 5
        value: Math.round(root.cfg_Speed * 100)
        onValueModified: root.cfg_Speed = value / 100
    }
    Controls.SpinBox {
        Kirigami.FormData.label: "Bilder pro Sekunde:"
        from: 10; to: 60
        value: root.cfg_Fps
        onValueModified: root.cfg_Fps = value
    }
    Controls.SpinBox {
        Kirigami.FormData.label: "Renderauflösung (%):"
        from: 40; to: 100; stepSize: 5
        value: root.cfg_Quality
        onValueModified: root.cfg_Quality = value
    }
    Controls.CheckBox {
        text: "Animation pausieren"
        checked: root.cfg_Paused
        onToggled: root.cfg_Paused = checked
    }
    Controls.CheckBox {
        text: "Bei Vollbildfenstern automatisch pausieren"
        checked: root.cfg_PauseFullscreen
        onToggled: root.cfg_PauseFullscreen = checked
    }
    RowLayout {
        visible: root.cfg_Theme === "neon" || root.cfg_Theme === "random"
        Kirigami.FormData.label: "Logo für Neon-Emblem-SDC:"
        Controls.TextField {
            Layout.fillWidth: true
            placeholderText: "Standard: Steam Deck Checker"
            text: root.cfg_LogoPath
            onTextEdited: root.cfg_LogoPath = text
        }
        Controls.Button { text: "Auswählen …"; onClicked: logoDialog.open() }
        Controls.Button { text: "Standardlogo"; onClicked: root.cfg_LogoPath = "" }
    }
    RowLayout {
        visible: root.cfg_Theme === "neon-bazzite" || root.cfg_Theme === "random"
        Kirigami.FormData.label: "Logo für Neon-Emblem-Bazzite:"
        Controls.TextField {
            Layout.fillWidth: true
            placeholderText: "Standard: Bazzite"
            text: root.cfg_BazziteLogoPath
            onTextEdited: root.cfg_BazziteLogoPath = text
        }
        Controls.Button { text: "Auswählen …"; onClicked: bazziteLogoDialog.open() }
        Controls.Button { text: "Standardlogo"; onClicked: root.cfg_BazziteLogoPath = "" }
    }
    RowLayout {
        visible: root.cfg_Theme === "orbs" || root.cfg_Theme === "random"
        Kirigami.FormData.label: "Bild hinter den Blasen SDC:"
        Controls.TextField {
            Layout.fillWidth: true
            placeholderText: "Standard: Steam Deck Checker Spielecollage"
            text: root.cfg_WallpaperPath
            onTextEdited: root.cfg_WallpaperPath = text
        }
        Controls.Button { text: "Auswählen …"; onClicked: wallpaperDialog.open() }
        Controls.Button { text: "Standardbild"; onClicked: root.cfg_WallpaperPath = "" }
    }
    RowLayout {
        visible: root.cfg_Theme === "orbs-bazzite" || root.cfg_Theme === "random"
        Kirigami.FormData.label: "Bild hinter den Blasen Bazzite:"
        Controls.TextField {
            Layout.fillWidth: true
            placeholderText: "Standard: Bazzite-Wallpaper"
            text: root.cfg_BazziteWallpaperPath
            onTextEdited: root.cfg_BazziteWallpaperPath = text
        }
        Controls.Button { text: "Auswählen …"; onClicked: bazziteWallpaperDialog.open() }
        Controls.Button { text: "Standardbild"; onClicked: root.cfg_BazziteWallpaperPath = "" }
    }
    Controls.SpinBox {
        Kirigami.FormData.label: "Bild abdunkeln (%):"
        from: 0; to: 90
        value: root.cfg_Dim
        onValueModified: root.cfg_Dim = value
    }
    Controls.Label {
        Layout.maximumWidth: 600
        wrapMode: Text.WordWrap
        text: "Live Background 0.3.2 für Plasma 6. Neon-Emblem und schwebende Blasen gibt es jeweils als SDC- und Bazzite-Variante. Zum Einstieg 24 FPS und 60 % Renderauflösung verwenden. Änderungen mit Anwenden übernehmen. Bei einer Pause hält auch der Zufallswechsel an."
    }
    FileDialog {
        id: logoDialog
        title: "Logo für Neon-Emblem-SDC auswählen"
        nameFilters: ["Bilder (*.png *.jpg *.jpeg *.webp *.svg)"]
        onAccepted: root.cfg_LogoPath = selectedFile.toString()
    }
    FileDialog {
        id: bazziteLogoDialog
        title: "Logo für Neon-Emblem-Bazzite auswählen"
        nameFilters: ["Bilder (*.png *.jpg *.jpeg *.webp *.svg)"]
        onAccepted: root.cfg_BazziteLogoPath = selectedFile.toString()
    }
    FileDialog {
        id: wallpaperDialog
        title: "Hintergrundbild für schwebende Blasen SDC auswählen"
        nameFilters: ["Bilder (*.png *.jpg *.jpeg *.webp)"]
        onAccepted: root.cfg_WallpaperPath = selectedFile.toString()
    }
    FileDialog {
        id: bazziteWallpaperDialog
        title: "Hintergrundbild für schwebende Blasen Bazzite auswählen"
        nameFilters: ["Bilder (*.png *.jpg *.jpeg *.webp)"]
        onAccepted: root.cfg_BazziteWallpaperPath = selectedFile.toString()
    }
}

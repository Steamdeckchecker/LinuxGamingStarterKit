// Animationen: https://github.com/ryth9419-jpg/livewallpaper
// Quelle: live-background.zip, Git-Blob 57f437a02ccb11c8282ecc3daacd48227b0fc34f.
// KDE-Port 0.3.2: Neun interaktive Motive für Maus, Touchpad und Touchscreen.

const THEMES = [
    ['matrix', 'Matrix rain'],
    ['code', 'Code stream'],
    ['storm', 'Thunderstorm'],
    ['starfield', 'Starfield'],
    ['fireflies', 'Fireflies'],
    ['neon', 'Neon-Emblem-SDC'],
    ['neon-bazzite', 'Neon-Emblem-Bazzite'],
    ['orbs', 'Schwebende Blasen SDC'],
    ['orbs-bazzite', 'Schwebende Blasen Bazzite'],
];

const TAU = Math.PI * 2;
const rand = (a, b) => a + Math.random() * (b - a);

function makeThemes(env) {
    const ctx = env.ctx, W = env.W, H = env.H;
    const dot = (x, y, r) => { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); };

    /* Matrix rain: characters glitch out when the mouse moves through them */
    const matrix = (() => {
        const fs = 18;
        const chars = Array.from('アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン0123456789Z:.=*+-<>');
        let drops = [], speeds = [], rain = null, glyphsR = null, glyphsM = null, cols = 0, rows = 0, cell = null, born = null;
        let t = 0, lastP = null, gUntil = null, gNext = null, gShift = null, gGlyph = null;
        const active = new Set();
        const GLITCH = ['rgba(255,42,109,', 'rgba(5,217,232,', 'rgba(255,255,255,', 'rgba(216,255,216,'];
        function init() {
            rain = makeLayer(W, H, env.rs);
            glyphsR = chars.map(ch => rain.ctx.layout(ch, fs));
            if (!glyphsM) glyphsM = chars.map(ch => ctx.layout(ch, fs));
            cols = Math.ceil(W / fs); rows = Math.ceil(H / fs);
            cell = new Int16Array(cols * rows).fill(-1); born = new Float32Array(cols * rows);
            drops = Array.from({length: cols}, () => rand(-H / fs, 0));
            speeds = Array.from({length: cols}, () => rand(0.6, 1.4));
            rain.ctx.fillStyle = '#000000'; rain.ctx.fillRect(0, 0, W, H);
            gUntil = new Float32Array(cols * rows); gNext = new Float32Array(cols * rows); gShift = new Float32Array(cols * rows); gGlyph = new Int16Array(cols * rows);
            active.clear(); t = 0; lastP = null;
        }
        function frame(dt) {
            t += dt;
            // the rain itself, drawn into its own fading layer
            const r = rain.ctx;
            r.fillStyle = `rgba(0,0,0,${Math.min(1, dt * 3).toFixed(2)})`;
            r.fillRect(0, 0, W, H);
            for (let i = 0; i < drops.length; i++) {
                const prev = Math.floor(drops[i]);
                drops[i] += speeds[i] * dt * 18;
                const row = Math.floor(drops[i]);
                if (row !== prev && row >= 0 && row < rows) {
                    const gi = (Math.random() * glyphsR.length) | 0;
                    r.fillStyle = Math.random() < 0.12 ? '#d8ffd8' : '#33f06a';
                    r.drawLayout(glyphsR[gi], i * fs, row * fs);
                    cell[row * cols + i] = gi; born[row * cols + i] = t;
                }
                if (row * fs > H && Math.random() < 0.03)
                    drops[i] = rand(-20, 0);
            }
            ctx.drawImage(rain, 0, 0);

            // glitch: characters the mouse passes through scramble and flicker for a moment
            const p = env.pointer;
            if (p && lastP && Math.hypot(p.x - lastP.x, p.y - lastP.y) > 1) {
                const steps = Math.min(12, Math.ceil(Math.hypot(p.x - lastP.x, p.y - lastP.y) / (fs * 0.7)));
                for (let s2 = 1; s2 <= steps; s2++) {
                    const x = lastP.x + (p.x - lastP.x) * s2 / steps, y = lastP.y + (p.y - lastP.y) * s2 / steps;
                    const cc = Math.floor(x / fs), rr = Math.floor(y / fs);
                    for (let dc = -1; dc <= 1; dc++) {
                        for (let dr = -1; dr <= 1; dr++) touch(cc + dc, rr + dr, dc === 0 && dr === 0 ? 1 : 0.55);
                    }
                }
            }
            lastP = p ? {x: p.x, y: p.y} : null;
            if (!active.size) return;
            const k = H / 1080;
            for (const idx of active) {
                const left = gUntil[idx] - t;
                if (left <= 0 || t - born[idx] > 2) { active.delete(idx); continue; }
                const c = idx % cols, rw = (idx / cols) | 0;
                if (t > gNext[idx]) { gNext[idx] = t + rand(0.04, 0.12); gShift[idx] = Math.random() < 0.5 ? rand(-0.45, 0.45) * fs : 0; gGlyph[idx] = (Math.random() * glyphsM.length) | 0; }
                if (Math.random() < 0.12) continue;          // flicker out now and then
                const a = Math.min(1, left * 2.5) * Math.max(0.25, 1 - (t - born[idx]) / 2);
                const x = c * fs + gShift[idx], y = rw * fs, off = 2.5 * k;
                ctx.fillStyle = 'rgba(0,0,0,.92)'; ctx.fillRect(c * fs, y, fs, fs);
                ctx.globalCompositeOperation = 'lighter';
                ctx.fillStyle = `${GLITCH[0]}${(a * 0.75).toFixed(2)})`; ctx.drawLayout(glyphsM[gGlyph[idx]], x - off, y);
                ctx.fillStyle = `${GLITCH[1]}${(a * 0.75).toFixed(2)})`; ctx.drawLayout(glyphsM[gGlyph[idx]], x + off, y);
                ctx.globalCompositeOperation = 'source-over';
                ctx.fillStyle = Math.random() < 0.5 ? `${GLITCH[3]}${a.toFixed(2)})` : `rgba(51,240,106,${a.toFixed(2)})`;
                ctx.drawLayout(glyphsM[(gGlyph[idx] + 11) % glyphsM.length], x, y);
            }
        }
        function touch(c, rw, strength) {
            if (c < 0 || rw < 0 || c >= cols || rw >= rows) return;
            const idx = rw * cols + c;
            if (cell[idx] < 0 || t - born[idx] > 1.6) return;          // only real, visible characters glitch
            if (Math.random() > strength) return;
            gUntil[idx] = Math.max(gUntil[idx], t + rand(0.25, 0.7));
            active.add(idx);
            // the glitch runs a little way up and down the same line of text
            for (const d of [-1, 1]) {
                let r2 = rw + d, n = (Math.random() * 3) | 0;
                while (n-- > 0 && r2 >= 0 && r2 < rows) {
                    const j = r2 * cols + c;
                    if (cell[j] >= 0 && t - born[j] < 1.6) { gUntil[j] = Math.max(gUntil[j], t + rand(0.15, 0.45)); active.add(j); }
                    r2 += d;
                }
            }
        }
        return {init, frame};
    })();

    /* Code stream */
    const code = (() => {
        const SNIPPETS = [
            'const frame = (dt) => render(scene, dt);', 'if (fullscreen) pause(); else resume();',
            'for (let i = 0; i < cols; i++) drop(i);', 'fn main() { let mut rng = rand::thread_rng(); }',
            'git commit -m "fix shader uniforms"', 'while True: monitor.poll(interval=1.0)',
            'export default class LiveBackground extends Extension {}', 'glUniform1f(timeLoc, elapsed);',
            'return new Promise(r => setTimeout(r, 16));', 'SELECT name, ram_mb FROM procs ORDER BY ram_mb DESC;',
            'let theme = settings.get_string("theme");', 'printf("%d frames\\n", count);',
            'import Gio from "gi://Gio";', 'def swirl(p, t): return rotate(p, t * 0.5)',
            'const x = Math.sin(t * 2.0) * 0.5 + 0.5;', 'for (const w of windows) w.minimize();',
            'uniform float u_time; varying vec2 uv;', 'if (err) throw new Error("no display");',
            'async function load() { const res = await fetch(url); return res.json(); }',
            'struct Particle { x: f32, y: f32, vx: f32, vy: f32 }',
            'impl Particle { pub fn step(&mut self, dt: f32) { self.x += self.vx * dt; } }',
            'use std::collections::HashMap;', 'match event { Event::Quit => break, _ => continue }',
            'int main(void) { return render_loop(); }', 'static char buffer[4096];',
            'func main() { http.ListenAndServe(":8080", nil) }', 'package main',
            'public static void main(String[] args) { run(); }', 'try { parse(input); } catch (e) { log(e); }',
            'except KeyError as err: print(err)', 'squares = [n * n for n in range(64)]',
            'lambda x: x * 0.5 + offset', 'switch (state) { case IDLE: wake(); break; }',
            'for f in *.rpm; do sudo dnf install "$f"; done', 'if [ -f ~/.config/live-bg.conf ]; then echo "loaded"; fi',
            'echo "frames: $FPS"', 'INSERT INTO scores (player, points) VALUES ("p1", 42);',
            'SELECT * FROM matches WHERE winner IS NOT null;', 'interface Theme { name: string; fps: number; }',
            'type Vec2 = { x: number; y: number };', 'enum Mode { Play, Pause, Hidden }',
            'const shader = gl.createShader(gl.FRAGMENT_SHADER);', 'gl_FragColor = vec4(uv.x, uv.y, sin(u_time), 1.0);',
            'float d = length(uv - 0.5); col *= smoothstep(0.4, 0.0, d);', 'with open("log.txt") as f: lines = f.readlines()',
            'yield from walk(tree.left)', 'loop { let frame = rx.recv()?; draw(frame); }',
            'docker run --rm -it fedora:latest bash', 'ssh root@10.0.0.2 "uptime"',
            'window.addEventListener("resize", resize);', 'this.timer = setInterval(() => this.tick(), 1000);',
            'self.velocity = self.velocity.lerp(target, 0.1)', 'nums.sort((a, b) => b - a).slice(0, 10);',
            '0x7f3a 0x00ff 0xdead 0xbeef 0x1337 0xc0de', 'Array.from({ length: 8 }, (_, i) => i * i);',
            'const [state, setState] = useState(false);', 'printf("cpu: %.1f%%\\n", load * 100.0);',
            'git push origin main --force-with-lease', 'chmod +x LiveBackground.AppImage && ./LiveBackground.AppImage',
            'while read -r line; do echo "$line"; done < input.txt', '@keyframes spin { to { transform: rotate(360deg); } }',
            '.dock { display: flex; gap: 8px; backdrop-filter: blur(12px); }', '<div class="matrix" data-speed="1.5"></div>',
            'malloc(sizeof(struct node) * count);', 'if (x > W || x < 0) vx = -vx;',
            'return a.score > b.score ? a : b;', '10110100 01101001 11100010 00011111',
        ];
        const KW = /^(const|let|if|else|for|fn|def|return|while|True|export|default|class|extends|import|from|new|SELECT|FROM|ORDER|BY|DESC|git|mut|uniform|float|varying|vec2|vec4|throw|of|async|await|function|struct|impl|pub|use|match|int|void|char|static|public|func|package|var|try|catch|except|in|lambda|switch|case|break|echo|then|fi|do|done|WHERE|INSERT|INTO|VALUES|IS|NOT|null|true|false|self|this|type|interface|enum|loop|yield|with|as|sudo|continue)$/;
        let lanes = [];
        function markup(text, alpha) {
            const spans = (text.match(/"[^"]*"|\w+|\s+|[^\w\s]/g) || []).map(t => {
                let col = '#b8c2d1';
                if (KW.test(t)) col = '#7aa2ff';
                else if (t[0] === '"') col = '#f2b36b';
                else if (/^\d/.test(t)) col = '#c58cff';
                else if (/^[^\w\s]$/.test(t)) col = '#6b7688';
                return `<span foreground="${col}">${GLib.markup_escape_text(t, -1)}</span>`;
            });
            return `<span fgalpha="${Math.round(alpha * 100)}%">${spans.join('')}</span>`;
        }
        function fill(l, initial) {
            l.size = Math.round(rand(11, 22));
            const parts = Array.from({length: 2 + ((Math.random() * 3) | 0)}, () => SNIPPETS[(Math.random() * SNIPPETS.length) | 0]);
            const alpha = 0.25 + (l.size - 11) / 11 * 0.65;
            l.layout = ctx.layout(markup(parts.join('      '), alpha), l.size, true);
            l.width = l.layout.get_pixel_size()[0];
            l.speed = l.size * rand(4, 8);
            l.focus = 0;
            l.x = initial ? rand(-l.width, W) : -l.width - rand(0, W * 0.6);
        }
        function init() {
            const gap = 21, n = Math.ceil(H / gap) + 1;
            lanes = Array.from({length: n}, (_, i) => {
                const l = {y: i * gap + rand(-4, 4)};
                fill(l, true);
                return l;
            });
        }
        function frame(dt) {
            ctx.fillStyle = '#070a10';
            ctx.fillRect(0, 0, W, H);
            const p = env.pointer;
            if (p) {
                const radius = Math.max(70, H * 0.18);
                const light = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, radius);
                light.addColorStop(0, 'rgba(75,130,255,.2)');
                light.addColorStop(1, 'rgba(75,130,255,0)');
                ctx.fillStyle = light;
                ctx.fillRect(p.x - radius, p.y - radius, radius * 2, radius * 2);
            }
            for (const l of lanes) {
                const focus = p ? Math.max(0, 1 - Math.abs(p.y - l.y) / Math.max(45, H * 0.1)) : 0;
                l.focus += (focus - l.focus) * Math.min(1, dt * 8);
                l.x += l.speed * dt * (1 - l.focus * 0.65);
                if (l.x > W)
                    fill(l, false);
                ctx.drawLayout(l.layout, l.x, l.y - l.size * 0.6);
            }
        }
        return {init, frame};
    })();

    /* Thunderstorm: drifting clouds, layered rain, splashes, lightning, drops on the glass */
    const storm = (() => {
        let sky = null, hills = null, clouds = [], drops = [], splashes = [], bolts = [], beads = [];
        let flash = 0, pulses = [], since = 0, nextStrike = 3, nextBead = 4, t = 0, horizon = 0, pointerWind = 0;
        const RAIN = [[190, 200, 220, 0.14, 0.7], [195, 205, 225, 0.24, 1.0], [205, 215, 235, 0.38, 1.5]];
        const rainBuckets = [[], [], []];

        function cloudPair(h, count, dark, seedY) {
            const dk = makeLayer(W, h, env.rs), lt = makeLayer(W, h, env.rs);
            for (let i = 0; i < count; i++) {
                const x = rand(0, W), y = rand(-h * 0.1, h * seedY), r = rand(h * 0.12, h * 0.38);
                for (const ox of [0, -W, W]) {
                    if (x + ox + r < 0 || x + ox - r > W) continue;
                    for (const [L, c, a] of [[dk, dark, 0.5], [lt, [150, 165, 205], 0.32]]) {
                        const g = L.ctx.createRadialGradient(x + ox, y, 0, x + ox, y, r);
                        g.addColorStop(0, `rgba(${c[0]},${c[1]},${c[2]},${a})`);
                        g.addColorStop(1, `rgba(${c[0]},${c[1]},${c[2]},0)`);
                        L.ctx.fillStyle = g;
                        L.ctx.fillRect(x + ox - r, y - r, r * 2, r * 2);
                    }
                }
            }
            return {dk, lt, off: rand(0, W)};
        }
        function newDrop(d, initial) {
            d.z = Math.random();
            d.l = 14 + d.z * 34;
            d.v = 650 + d.z * 950;
            d.x = rand(-W * 0.2, W);
            d.y = initial ? rand(-H, H) : rand(-H * 0.3, -20);
            d.gy = horizon + rand(-H * 0.02, H - horizon) * (0.3 + d.z * 0.7);
        }
        function bolt(x0, y0, x1, y1, disp, iters) {
            let pts = [[x0, y0], [x1, y1]];
            for (let it = 0; it < iters; it++) {
                const np = [pts[0]];
                for (let i = 0; i < pts.length - 1; i++) {
                    const [ax, ay] = pts[i], [bx, by] = pts[i + 1];
                    np.push([(ax + bx) / 2 + rand(-1, 1) * disp, (ay + by) / 2 + rand(-0.25, 0.25) * disp], [bx, by]);
                }
                pts = np;
                disp *= 0.55;
            }
            return pts;
        }
        function strike() {
            since = 0;
            const sheet = Math.random() < 0.35;
            pulses = sheet ? [[0, 0.45], [0.15, 0.3]] : [[0, 1], [0.09, 0.45], [0.2, 0.85], [0.34, 0.4]];
            if (sheet) return;
            const x = rand(W * 0.08, W * 0.92), top = rand(H * 0.04, H * 0.18);
            const gx = x + rand(-W * 0.12, W * 0.12), gy = horizon + rand(0, (H - horizon) * 0.25);
            const main = bolt(x, top, gx, gy, W * 0.07, 7);
            const paths = [{pts: main, w: 1}];
            const nb = (rand(2, 6)) | 0;
            for (let b = 0; b < nb; b++) {
                const [sx, sy] = main[(rand(0.1, 0.7) * main.length) | 0];
                const len = rand(H * 0.08, H * 0.26), ang = Math.PI / 2 + rand(-1.1, 1.1);
                paths.push({pts: bolt(sx, sy, sx + Math.cos(ang) * len, sy + Math.sin(ang) * len, len * 0.25, 5), w: rand(0.35, 0.6)});
            }
            bolts.push({paths, life: 0.45, max: 0.45, gx, gy});
        }
        function newBead() {
            const r = rand(6, 17);
            beads.push({x: rand(W * 0.04, W * 0.96), y: rand(H * 0.04, H * 0.7), r, life: rand(7, 14), age: 0,
                vy: 0, slide: rand(1, 3), trail: [], tmp: makeLayer(r * 4, r * 4, env.rs)});
        }
        function init() {
            horizon = H * 0.8;
            sky = ctx.createLinearGradient(0, 0, 0, H);
            sky.addColorStop(0, '#06080d'); sky.addColorStop(0.6, '#0e121a'); sky.addColorStop(1, '#151a22');
            clouds = [cloudPair(H * 0.5, 26, [34, 38, 48], 0.7), cloudPair(H * 0.62, 22, [20, 23, 30], 0.6)];
            clouds[0].speed = 6; clouds[1].speed = 16;
            hills = makeLayer(W, H - horizon + H * 0.08, env.rs);
            const g = hills.ctx, hh = hills.h;
            g.fillStyle = '#05060a';
            g.beginPath(); g.moveTo(0, hh);
            for (let x = 0; x <= W + 20; x += 20) {
                const y = H * 0.08 + Math.sin(x * 0.004) * H * 0.025 + Math.sin(x * 0.011 + 2) * H * 0.012 + rand(-2, 2);
                g.lineTo(x, y);
            }
            g.lineTo(W, hh); g.closePath(); g.fill();
            const n = Math.round(Math.min(1100, W * H / 1800));
            drops = Array.from({length: n}, () => { const d = {}; newDrop(d, true); return d; });
            splashes = []; bolts = []; beads = []; pulses = []; flash = 0; t = 0; pointerWind = 0;
            nextStrike = rand(2, 5); nextBead = rand(3, 6);
        }
        function drawClouds(c, lit) {
            const y = 0;
            ctx.drawImage(c.dk, c.off - W, y); ctx.drawImage(c.dk, c.off, y);
            if (lit > 0.02) {
                ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = Math.min(1, lit);
                ctx.drawImage(c.lt, c.off - W, y); ctx.drawImage(c.lt, c.off, y);
                ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
            }
        }
        function drawBolts() {
            ctx.globalCompositeOperation = 'lighter'; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
            for (const b of bolts) {
                const a = Math.max(0, Math.min(1, flash * 1.2)) * (b.life / b.max) ** 0.5;
                if (a < 0.02) continue;
                for (const [wm, col, al] of [[9, '150,165,255', 0.12], [3.5, '190,200,255', 0.35], [1.4, '255,255,255', 1]]) {
                    for (const p of b.paths) {
                        ctx.strokeStyle = `rgba(${col},${(al * a).toFixed(2)})`; ctx.lineWidth = wm * p.w;
                        ctx.beginPath(); ctx.moveTo(p.pts[0][0], p.pts[0][1]);
                        for (let i = 1; i < p.pts.length; i++) ctx.lineTo(p.pts[i][0], p.pts[i][1]);
                        ctx.stroke();
                    }
                }
                const gr = ctx.createRadialGradient(b.gx, b.gy, 0, b.gx, b.gy, H * 0.15);
                gr.addColorStop(0, `rgba(200,210,255,${(0.45 * a).toFixed(2)})`); gr.addColorStop(1, 'rgba(200,210,255,0)');
                ctx.fillStyle = gr; ctx.fillRect(b.gx - H * 0.15, b.gy - H * 0.15, H * 0.3, H * 0.3);
            }
            ctx.globalCompositeOperation = 'source-over';
        }
        function rain(dt) {
            const wind = 0.16 + Math.sin(t * 0.35) * 0.07 + pointerWind;
            for (const b of rainBuckets) b.length = 0;
            for (const d of drops) {
                d.y += d.v * dt; d.x += d.v * wind * dt;
                if (d.y >= d.gy) {
                    if (d.z > 0.45 && splashes.length < 220) {
                        for (let k = 0; k < 2; k++) splashes.push({x: d.x, y: d.gy, vx: rand(-60, 60) * d.z, vy: -rand(40, 110) * d.z, life: rand(0.15, 0.3)});
                    }
                    newDrop(d, false);
                    continue;
                }
                const bi = d.z < 0.4 ? 0 : d.z < 0.75 ? 1 : 2;
                rainBuckets[bi].push(d.x, d.y, d.x - d.l * wind, d.y - d.l);
            }
            ctx.lineCap = 'butt';
            RAIN.forEach(([r, g, b, a, w], i) => {
                const s = rainBuckets[i];
                if (!s.length) return;
                ctx.strokeStyle = `rgba(${r},${g},${b},${a})`; ctx.lineWidth = w;
                ctx.beginPath();
                for (let k = 0; k < s.length; k += 4) { ctx.moveTo(s[k], s[k + 1]); ctx.lineTo(s[k + 2], s[k + 3]); }
                ctx.stroke();
            });
            ctx.fillStyle = 'rgba(200,210,230,.45)';
            for (let i = splashes.length - 1; i >= 0; i--) {
                const p = splashes[i];
                p.life -= dt;
                if (p.life <= 0) { splashes.splice(i, 1); continue; }
                p.vy += 500 * dt; p.x += p.vx * dt; p.y += p.vy * dt;
                ctx.fillRect(p.x, p.y, 1.4, 1.4);
            }
        }
        function glass(dt) {
            nextBead -= dt;
            if (nextBead <= 0 && beads.length < 5) { newBead(); nextBead = rand(4, 10); }
            for (let i = beads.length - 1; i >= 0; i--) {
                const d = beads[i];
                d.age += dt; d.life -= dt; d.slide -= dt;
                if (d.slide <= 0) { d.vy = rand(50, 140); d.slide = rand(1.5, 4); }
                if (d.vy > 0) {
                    d.y += d.vy * dt; d.vy *= Math.exp(-dt * 2.5);
                    if (Math.random() < dt * 8) d.trail.push({x: d.x + rand(-1.5, 1.5), y: d.y - d.r * 0.7, r: rand(0.8, 2.2), life: rand(2, 4)});
                    if (d.vy < 6) d.vy = 0;
                }
                if (d.life <= 0 || d.y - d.r > H) { beads.splice(i, 1); continue; }
                const a = Math.min(1, d.life, d.age * 4), r = d.r * Math.min(1, 0.4 + d.age * 3);
                for (let k = d.trail.length - 1; k >= 0; k--) {
                    const tr = d.trail[k];
                    tr.life -= dt;
                    if (tr.life <= 0) { d.trail.splice(k, 1); continue; }
                    ctx.fillStyle = `rgba(200,210,230,${(0.22 * Math.min(1, tr.life)).toFixed(2)})`; dot(tr.x, tr.y, tr.r);
                }
                // Refraction: grab what is behind the drop and show it shrunk and upside down.
                const T = d.tmp;
                T.ctx.drawImage(env.main, -(d.x - d.r * 2), -(d.y - d.r * 2));
                ctx.save();
                ctx.beginPath(); ctx.arc(d.x, d.y, r, 0, TAU); ctx.clip();
                ctx.translate(d.x, d.y); ctx.scale(1, -1);
                ctx.globalAlpha = a;
                ctx.drawImage(T, -r * 1.15, -r * 1.15, r * 2.3, r * 2.3);
                ctx.restore();
                ctx.strokeStyle = `rgba(0,0,0,${(0.35 * a).toFixed(2)})`; ctx.lineWidth = r * 0.14;
                ctx.beginPath(); ctx.arc(d.x, d.y, r * 0.93, 0, TAU); ctx.stroke();
                ctx.strokeStyle = `rgba(255,255,255,${(0.2 * a).toFixed(2)})`; ctx.lineWidth = r * 0.12;
                ctx.beginPath(); ctx.arc(d.x, d.y, r * 0.75, 0.25 * Math.PI, 0.75 * Math.PI); ctx.stroke();
                ctx.fillStyle = `rgba(255,255,255,${(0.6 * a).toFixed(2)})`;
                ctx.beginPath(); ctx.ellipse(d.x - r * 0.35, d.y - r * 0.42, r * 0.28, r * 0.15, -0.6, 0, TAU); ctx.fill();
            }
        }
        function frame(dt) {
            t += dt; since += dt;
            const p = env.pointer;
            const targetWind = p ? (p.x / W - 0.5) * 0.7 : 0;
            pointerWind += (targetWind - pointerWind) * Math.min(1, dt * 4);
            nextStrike -= dt;
            if (nextStrike <= 0) { strike(); nextStrike = rand(2.5, 9); }
            for (const [at, amp] of pulses) {
                if (since >= at && since - dt < at) flash = Math.max(flash, amp);
            }
            flash *= Math.exp(-dt * 7);
            for (let i = bolts.length - 1; i >= 0; i--) { bolts[i].life -= dt; if (bolts[i].life <= 0) bolts.splice(i, 1); }
            for (const c of clouds) { c.off = (c.off + c.speed * dt) % W; }

            ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
            drawClouds(clouds[0], flash * 0.8);
            drawBolts();
            drawClouds(clouds[1], flash);
            ctx.drawImage(hills, 0, horizon - H * 0.08);
            rain(dt);
            if (flash > 0.02) { ctx.fillStyle = `rgba(200,210,255,${(flash * 0.22).toFixed(2)})`; ctx.fillRect(0, 0, W, H); }
            glass(dt);
            if (p) {
                const radius = Math.max(60, H * 0.16);
                const reflection = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, radius);
                reflection.addColorStop(0, 'rgba(180,205,255,.14)');
                reflection.addColorStop(1, 'rgba(180,205,255,0)');
                ctx.fillStyle = reflection;
                ctx.fillRect(p.x - radius, p.y - radius, radius * 2, radius * 2);
            }
        }
        return {init, frame};
    })();

    /* Starfield with a nebula backdrop, passing suns and planets */
    const starfield = (() => {
        const LEVELS = 10;
        let S = [], P = [], sun = null, neb = null, t = 0, aimX = 0, aimY = 0;
        const buckets = Array.from({length: LEVELS}, () => []);
        const PLANETS = [
            {light: '#f6d2a2', base: '#d9a066', dark: '#5a3a1c', bands: ['rgba(120,70,30,.35)', 'rgba(255,230,190,.25)'], ring: false},
            {light: '#fff3d6', base: '#e2cc96', dark: '#6b5a3a', bands: ['rgba(150,120,70,.3)'], ring: true},
            {light: '#a8d4ff', base: '#3f7fd0', dark: '#0c1f45', bands: ['rgba(80,170,90,.45)', 'rgba(255,255,255,.3)'], ring: false},
            {light: '#f0a080', base: '#c2553a', dark: '#3b120a', bands: [], ring: false},
            {light: '#d8fbff', base: '#7fd6e0', dark: '#1d4a5a', bands: ['rgba(255,255,255,.18)'], ring: true},
            {light: '#e2d4ff', base: '#a58bd9', dark: '#2a1d4a', bands: ['rgba(60,30,110,.35)', 'rgba(255,255,255,.15)'], ring: false},
        ];
        const SUNS = [
            {core: '#fffbe8', glow: '255,200,90'},
            {core: '#ffffff', glow: '150,190,255'},
            {core: '#fff2dc', glow: '255,120,60'},
            {core: '#fff0f8', glow: '255,120,190'},
        ];
        const NEB = [[120, 60, 210], [210, 60, 150], [60, 110, 230], [40, 190, 210], [230, 120, 60], [90, 200, 140]];
        const gauss = () => (rand(-1, 1) + rand(-1, 1) + rand(-1, 1)) / 3;

        function buildNebula() {
            const L = makeLayer(W * 1.3, H * 1.3, env.rs), g = L.ctx;
            g.globalCompositeOperation = 'lighter';
            const clouds = 2 + ((Math.random() * 2) | 0);
            for (let c = 0; c < clouds; c++) {
                const cx = rand(0.15, 0.85) * L.w, cy = rand(0.15, 0.85) * L.h;
                const pal = [NEB[(Math.random() * NEB.length) | 0], NEB[(Math.random() * NEB.length) | 0]];
                for (let i = 0; i < 45; i++) {
                    const x = cx + gauss() * L.w * 0.35, y = cy + gauss() * L.h * 0.3, r = rand(0.04, 0.17) * L.w;
                    const col = pal[i % 2], a = rand(0.04, 0.09);
                    const gr = g.createRadialGradient(x, y, 0, x, y, r);
                    gr.addColorStop(0, `rgba(${col[0]},${col[1]},${col[2]},${a.toFixed(3)})`);
                    gr.addColorStop(1, `rgba(${col[0]},${col[1]},${col[2]},0)`);
                    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
                }
            }
            g.globalCompositeOperation = 'source-over';
            for (let i = 0; i < 18; i++) {
                const x = rand(0, L.w), y = rand(0, L.h), r = rand(0.03, 0.1) * L.w;
                const gr = g.createRadialGradient(x, y, 0, x, y, r);
                gr.addColorStop(0, 'rgba(0,0,6,.35)'); gr.addColorStop(1, 'rgba(0,0,6,0)');
                g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
            }
            return L;
        }
        function reset(s, initial) { s.x = rand(-1, 1); s.y = rand(-1, 1); s.z = initial ? rand(0.05, 1) : 1; s.pz = s.z; }
        function resetP(p, initial) {
            p.def = PLANETS[(Math.random() * PLANETS.length) | 0];
            const a = rand(0, TAU), m = rand(0.2, 1);
            p.x = Math.cos(a) * m; p.y = Math.sin(a) * m;
            p.z = initial ? rand(0.3, 1) : 1;
            p.r = rand(0.006, 0.02); p.tilt = rand(-0.6, 0.6);
            p.bands = Array.from({length: 4}, () => ({o: rand(-0.9, 0.7), w: rand(0.08, 0.25)}));
            p.wait = initial ? rand(0, 2) : rand(1, 6);
        }
        function resetSun(s, initial) {
            s.def = SUNS[(Math.random() * SUNS.length) | 0];
            const a = rand(0, TAU), m = rand(0.3, 0.9);
            s.x = Math.cos(a) * m; s.y = Math.sin(a) * m;
            s.z = 1; s.r = rand(0.008, 0.02); s.spin = rand(0, TAU);
            s.wait = initial ? rand(3, 8) : rand(8, 20);
        }
        function init() {
            const n = Math.round(Math.min(700, W * H / 2600));
            S = Array.from({length: n}, () => { const s = {}; reset(s, true); return s; });
            P = Array.from({length: 2}, () => { const p = {}; resetP(p, true); return p; });
            sun = {}; resetSun(sun, true);
            neb = buildNebula();
            t = 0; aimX = 0; aimY = 0;
        }
        function ring(p, sx, sy, R, front) {
            ctx.save(); ctx.translate(sx, sy); ctx.rotate(p.tilt);
            ctx.beginPath(); ctx.rect(-R * 3, front ? 0 : -R * 1.2, R * 6, R * 1.2); ctx.clip();
            ctx.strokeStyle = 'rgba(235,220,185,.55)'; ctx.lineWidth = R * 0.22;
            ctx.beginPath(); ctx.ellipse(0, 0, R * 1.9, R * 0.45, 0, 0, TAU); ctx.stroke();
            ctx.strokeStyle = 'rgba(235,220,185,.3)'; ctx.lineWidth = R * 0.1;
            ctx.beginPath(); ctx.ellipse(0, 0, R * 2.3, R * 0.56, 0, 0, TAU); ctx.stroke();
            ctx.restore();
        }
        function planet(p, sx, sy, R) {
            const d = p.def;
            if (d.ring) ring(p, sx, sy, R, false);
            const g = ctx.createRadialGradient(sx - R * 0.35, sy - R * 0.35, R * 0.05, sx, sy, R);
            g.addColorStop(0, d.light); g.addColorStop(0.6, d.base); g.addColorStop(1, d.dark);
            ctx.fillStyle = g; dot(sx, sy, R);
            if (d.bands.length) {
                ctx.save(); ctx.beginPath(); ctx.arc(sx, sy, R, 0, TAU); ctx.clip();
                ctx.translate(sx, sy); ctx.rotate(p.tilt);
                p.bands.forEach((b, i) => { ctx.fillStyle = d.bands[i % d.bands.length]; ctx.fillRect(-R, b.o * R, R * 2, b.w * R); });
                ctx.restore();
            }
            const sh = ctx.createRadialGradient(sx - R * 0.45, sy - R * 0.45, R * 0.3, sx - R * 0.2, sy - R * 0.2, R * 1.6);
            sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,6,.85)');
            ctx.fillStyle = sh; dot(sx, sy, R);
            if (d.ring) ring(p, sx, sy, R, true);
        }
        function drawSun(s, sx, sy, R) {
            const gl = s.def.glow;
            ctx.globalCompositeOperation = 'lighter';
            const c = ctx.createRadialGradient(sx, sy, 0, sx, sy, R * 7);
            c.addColorStop(0, `rgba(${gl},.55)`); c.addColorStop(0.18, `rgba(${gl},.2)`); c.addColorStop(1, `rgba(${gl},0)`);
            ctx.fillStyle = c; ctx.fillRect(sx - R * 7, sy - R * 7, R * 14, R * 14);
            ctx.lineCap = 'round';
            for (let i = 0; i < 6; i++) {
                const a = s.spin + t * 0.15 + i * Math.PI / 3, len = R * (i % 2 ? 6 : 9);
                ctx.strokeStyle = `rgba(${gl},.12)`; ctx.lineWidth = Math.max(1, R * 0.12);
                ctx.beginPath(); ctx.moveTo(sx - Math.cos(a) * len, sy - Math.sin(a) * len); ctx.lineTo(sx + Math.cos(a) * len, sy + Math.sin(a) * len); ctx.stroke();
            }
            ctx.globalCompositeOperation = 'source-over';
            const core = ctx.createRadialGradient(sx, sy, 0, sx, sy, R);
            core.addColorStop(0, s.def.core); core.addColorStop(0.75, `rgba(${gl},1)`); core.addColorStop(1, `rgba(${gl},0)`);
            ctx.fillStyle = core; dot(sx, sy, R);
        }
        function frame(dt) {
            t += dt;
            const pointer = env.pointer;
            const follow = Math.min(1, dt * 4);
            aimX += ((pointer ? (pointer.x - W / 2) * 0.28 : 0) - aimX) * follow;
            aimY += ((pointer ? (pointer.y - H / 2) * 0.28 : 0) - aimY) * follow;
            ctx.fillStyle = '#000006'; ctx.fillRect(0, 0, W, H);
            ctx.drawImage(neb, -W * 0.15 + Math.sin(t * 0.02) * W * 0.1 + aimX * 0.2, -H * 0.15 + Math.cos(t * 0.017) * H * 0.1 + aimY * 0.2);
            const cx = W / 2 + aimX, cy = H / 2 + aimY, k = Math.max(W, H) * 0.5;
            for (const b of buckets) b.length = 0;
            for (const s of S) {
                s.pz = s.z; s.z -= dt * 0.3;
                if (s.z <= 0.02) { reset(s, false); continue; }
                const sx = cx + s.x / s.z * k, sy = cy + s.y / s.z * k;
                if (sx < -50 || sx > W + 50 || sy < -50 || sy > H + 50) { reset(s, false); continue; }
                const lvl = Math.min(LEVELS - 1, ((1 - s.z) * LEVELS) | 0);
                buckets[lvl].push(cx + s.x / s.pz * k, cy + s.y / s.pz * k, sx + 0.1, sy);
            }
            ctx.lineCap = 'round';
            for (let l = 0; l < LEVELS; l++) {
                const b = buckets[l];
                if (!b.length) continue;
                const tt = (l + 1) / LEVELS;
                ctx.strokeStyle = `rgba(210,225,255,${tt.toFixed(2)})`; ctx.lineWidth = 0.4 + tt * 2.4;
                ctx.beginPath();
                for (let i = 0; i < b.length; i += 4) { ctx.moveTo(b[i], b[i + 1]); ctx.lineTo(b[i + 2], b[i + 3]); }
                ctx.stroke();
            }
            if (sun.wait > 0) {
                sun.wait -= dt;
            } else {
                sun.z -= dt * 0.3;
                const sx = cx + sun.x / sun.z * k, sy = cy + sun.y / sun.z * k, R = sun.r / sun.z * k, m = R * 7;
                if (sun.z < 0.03 || sx + m < 0 || sx - m > W || sy + m < 0 || sy - m > H) resetSun(sun, false);
                else drawSun(sun, sx, sy, R);
            }
            P.sort((a, b) => b.z - a.z);
            for (const p of P) {
                if (p.wait > 0) { p.wait -= dt; continue; }
                p.z -= dt * 0.3;
                const sx = cx + p.x / p.z * k, sy = cy + p.y / p.z * k, R = p.r / p.z * k, m = R * 2.4;
                if (p.z < 0.03 || sx + m < 0 || sx - m > W || sy + m < 0 || sy - m > H) { resetP(p, false); continue; }
                planet(p, sx, sy, R);
            }
        }
        return {init, frame};
    })();

    /* Neon: a big pulsing emblem (your own image, chosen in Settings) on a dark blue/purple gaming backdrop */
    const neon = (() => {
        let t = 0, grid = 0, bg = null, parts = [], sparks = [], bolts = [], waves = [], trail = [];
        let nextBolt = 2, nextWave = 1, hover = 0, beat = 0, prevDown = false, cx = 0, cy = 0, L = 0, horizon = 0;
        const COLS = ['150,90,255', '90,120,255', '200,110,255', '110,170,255'];
        function makeBg() {
            bg = makeLayer(W, H, env.rs);
            const g = bg.ctx;
            const sky = g.createLinearGradient(0, 0, 0, H);
            sky.addColorStop(0, '#000004'); sky.addColorStop(0.55, '#03020e'); sky.addColorStop(1, '#050312');
            g.fillStyle = sky; g.fillRect(0, 0, W, H);
            // faint hex pattern
            g.strokeStyle = 'rgba(120,90,255,.02)'; g.lineWidth = 1;
            const hr = H * 0.035, hw = hr * Math.sqrt(3);
            g.beginPath();
            for (let row = 0; row * hr * 1.5 < horizon + hr; row++) {
                for (let col = -1; col * hw < W + hw; col++) {
                    const x = col * hw + (row % 2 ? hw / 2 : 0), y = row * hr * 1.5;
                    for (let i = 0; i <= 6; i++) {
                        const a = Math.PI / 6 + i * Math.PI / 3, px = x + Math.cos(a) * hr, py = y + Math.sin(a) * hr;
                        if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
                    }
                }
            }
            g.stroke();
            const hz = g.createLinearGradient(0, horizon - H * 0.12, 0, horizon + H * 0.04);
            hz.addColorStop(0, 'rgba(140,70,255,0)'); hz.addColorStop(0.8, 'rgba(140,70,255,.07)'); hz.addColorStop(1, 'rgba(140,70,255,0)');
            g.fillStyle = hz; g.fillRect(0, horizon - H * 0.12, W, H * 0.16);
        }
        function newPart(p, initial) {
            p.x = rand(0, W); p.y = initial ? rand(0, H) : H + 20;
            p.vx = rand(-8, 8); p.vy = -rand(10, 40);
            p.r = rand(1, 3.2); p.col = COLS[(Math.random() * COLS.length) | 0];
            p.kind = Math.random() < 0.18 ? 'plus' : Math.random() < 0.15 ? 'ring' : 'dot';
            p.rot = rand(0, TAU); p.spin = rand(-1, 1); p.glow = 0;
        }
        function init() {
            t = 0; cx = W / 2; cy = H * 0.45; L = Math.min(W, H) * 0.44; horizon = H * 0.7;
            makeBg();
            parts = Array.from({length: Math.round(Math.min(140, W * H / 15000))}, () => { const p = {}; newPart(p, true); return p; });
            sparks = []; bolts = []; waves = []; trail = []; hover = 0; nextBolt = 2; nextWave = 1; lastP = null; boomT = -1; flash = 0; pending = [];
        }
        function burst(x, y, n, speed, ang = null, spread = TAU, size = 1) {
            for (let i = 0; i < n && sparks.length < 900; i++) {
                const a = ang === null ? rand(0, TAU) : ang + rand(-spread / 2, spread / 2), v = speed * rand(0.4, 1);
                sparks.push({x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: rand(0.5, 1.2) * (0.6 + size * 0.4), max: 1, r: rand(1, 2.6) * size, col: COLS[(Math.random() * 3) | 0]});
                sparks[sparks.length - 1].max = sparks[sparks.length - 1].life;
            }
        }
        function hookSparks(n, size = 1) {
            const k = H / 1080;
            for (let i = 0; i < n && sparks.length < 900; i++) {
                const a = rand(0, TAU), v = rand(260, 520) * k * (0.6 + size * 0.4), life = rand(0.7, 1.3) * (0.7 + size * 0.3);
                sparks.push({x: cx + Math.cos(a) * L * 0.48, y: cy + Math.sin(a) * L * 0.48, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
                    life, max: life, r: rand(1.2, 2.6) * size, col: COLS[(Math.random() * 3) | 0], curl: (Math.random() < 0.5 ? -1 : 1) * rand(2, 4.5)});
            }
        }
        // Clicking the emblem: it bursts into a huge shower of neon sparks, then reforms.
        function explode() {
            const k = H / 1080;
            boomT = 0; flash = 0.6;
            for (let i = 0; i < 90; i++) {
                const a = rand(0, TAU);
                burst(cx + Math.cos(a) * L * 0.47, cy + Math.sin(a) * L * 0.47, 1, rand(450, 1000) * k, a, 0.4, rand(1.3, 2.2));
            }
            hookSparks(36, 1.8);
            shootBolts(10, 1.8);
            pending.push({at: 0.18, bolts: 6}, {at: 0.36, bolts: 4});
            for (const [at, w, life] of [[0, 10, 1.2], [0.12, 7, 1.4], [0.26, 5, 1.6]])
                pending.push({at, w: {x: cx, y: cy, r: L * 0.3, life, max: life, w}});
        }
        function shootBolts(n, size = 1) {
            for (let i = 0; i < n; i++) {
                const a = rand(0, TAU), r0 = L * 0.5, len = L * rand(0.5, 1.1) * size;
                const pts = [];
                let x = cx + Math.cos(a) * r0, y = cy + Math.sin(a) * r0;
                pts.push([x, y]);
                const steps = 9;
                for (let s = 1; s <= steps; s++) {
                    const f = s / steps, j = (1 - f * 0.5) * L * 0.05;
                    x = cx + Math.cos(a) * (r0 + len * f) + rand(-j, j); y = cy + Math.sin(a) * (r0 + len * f) + rand(-j, j);
                    pts.push([x, y]);
                }
                bolts.push({pts, life: 0.45 * (0.6 + size * 0.4), max: 0.45 * (0.6 + size * 0.4), w: size});
                burst(x, y, Math.round(10 * size), 220 * (H / 1080) * size, null, TAU, size > 1 ? 1.5 : 1);
            }
        }
        function drawLogo(scale, alpha) {
            const img = env.logo;
            if (!img) return;
            const fit = L / Math.max(img.w, img.h) * scale;
            const w = img.w * fit, h = img.h * fit;
            const ox = ptrOff[0], oy = ptrOff[1];
            ctx.globalAlpha = alpha;
            ctx.drawImage(img, cx - w / 2 + ox, cy - h / 2 + oy, w, h);
            ctx.globalAlpha = 1;
        }
        let ptrOff = [0, 0], lastP = null, wasPeak = false, wasHover = false, boomT = -1, flash = 0, pending = [];
        function frame(dt) {
            t += dt; grid = (grid + dt * 0.35) % 1;
            const p = env.pointer;
            const k = H / 1080;
            // pointer: hover over the emblem, click shockwaves, a glowing trail
            const dist = p ? Math.hypot(p.x - cx, p.y - cy) : Infinity;
            hover += ((env.logo && dist < L * 0.55 ? 1 : 0) - hover) * Math.min(1, dt * 5);
            ptrOff = [0, 0];
            if (p && p.down && !prevDown && p.free) {
                if (env.logo && dist < L * 0.5 && boomT < 0) explode();
                else { waves.push({x: p.x, y: p.y, r: 10, life: 1, max: 1, w: 3}); burst(p.x, p.y, 24, 320 * k); }
            }
            for (let i = pending.length - 1; i >= 0; i--) {
                pending[i].at -= dt;
                if (pending[i].at <= 0) { if (pending[i].w) waves.push(pending[i].w); if (pending[i].bolts) shootBolts(pending[i].bolts, 1.6); pending.splice(i, 1); }
            }
            if (boomT >= 0) { boomT += dt; if (boomT > 1.3) boomT = -1; }
            flash *= Math.exp(-dt * 5);
            prevDown = !!(p && p.down);
            // spark trail: the faster the mouse moves, the more sparks fly off it
            if (p && lastP) {
                const mvx = (p.x - lastP.x) / Math.max(dt, 0.001), mvy = (p.y - lastP.y) / Math.max(dt, 0.001), sp = Math.hypot(mvx, mvy);
                const nsp = Math.min(4, sp * dt / 16);
                for (let i = 0; i < nsp && trail.length < 500; i++) {
                    const f = Math.random(), life = rand(0.25, 0.55);
                    trail.push({x: lastP.x + (p.x - lastP.x) * f, y: lastP.y + (p.y - lastP.y) * f,
                        vx: -mvx * 0.08 + rand(-90, 90) * k, vy: -mvy * 0.08 + rand(-110, 30) * k, life, max: life, col: COLS[(Math.random() * 4) | 0]});
                }
            }
            lastP = p ? {x: p.x, y: p.y} : null;
            // heartbeat pulse
            // heavy double heartbeat ("lub-dub")
            const ph = (t * 0.33) % 1;
            beat = Math.exp(-Math.pow((ph - 0.04) / 0.02, 2)) + 0.7 * Math.exp(-Math.pow((ph - 0.12) / 0.022, 2));
            const has = !!env.logo;
            const peak = beat > 0.85;
            if (has && peak && !wasPeak) {
                waves.push({x: cx, y: cy, r: L * 0.45, life: 1.2, max: 1.2, w: 3});
                // little sparks on every beat; bigger and more of them while hovered
                if (hover > 0.3) hookSparks(Math.round(hover * 14));
                for (let i = 0; i < 12 + hover * 16; i++) {
                    const a = rand(0, TAU);
                    burst(cx + Math.cos(a) * L * 0.46, cy + Math.sin(a) * L * 0.46, 1, (260 + hover * 260) * k, a, 0.3, 0.45 + hover * 0.55);
                }
            }
            wasPeak = peak;
            // the emblem only fires energy bolts while the mouse is over it
            if (has && hover > 0.5 && !wasHover) { shootBolts(8); waves.push({x: cx, y: cy, r: L * 0.5, life: 1, max: 1, w: 8}); }
            wasHover = hover > 0.5;
            if (has && hover > 0.3) {
                nextBolt -= dt * (1 + hover * 2);
                if (nextBolt <= 0) { shootBolts((rand(2, 5) + hover * 2) | 0); nextBolt = rand(0.4, 1.1); }
            }
            if (has && hover > 0.5 && Math.random() < dt * 12) {
                const a = rand(0, TAU);
                burst(cx + Math.cos(a) * L * 0.45, cy + Math.sin(a) * L * 0.45, 3, 300 * k, a, 0.8);
            }

            ctx.drawImage(bg, 0, 0);
            ctx.globalCompositeOperation = 'lighter';
            // aurora ribbons
            for (let r = 0; r < 2; r++) {
                const base = H * (0.18 + r * 0.14), amp = H * 0.05, col = r ? '90,120,255' : '170,80,255';
                for (const [lw, a] of [[H * 0.09, 0.018], [H * 0.025, 0.035]]) {
                    ctx.strokeStyle = `rgba(${col},${a})`; ctx.lineWidth = lw; ctx.beginPath();
                    for (let x = -20; x <= W + 20; x += 30) {
                        const y = base + Math.sin(x * 0.004 + t * (0.35 + r * 0.2) + r) * amp + Math.sin(x * 0.011 - t * 0.5) * amp * 0.3;
                        if (x === -20) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                    }
                    ctx.stroke();
                }
            }
            // neon grid floor
            ctx.lineCap = 'butt';
            for (let i = 0; i < 16; i++) {
                const z = (i + grid) / 16, y = horizon + (H - horizon) * Math.pow(z, 2.2);
                ctx.strokeStyle = `rgba(150,80,255,${(0.03 + z * 0.17).toFixed(2)})`; ctx.lineWidth = 0.6 + z * 1.8;
                ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
            }
            ctx.strokeStyle = 'rgba(100,110,255,.1)'; ctx.lineWidth = 1.1; ctx.beginPath();
            for (let j = -18; j <= 18; j++) { ctx.moveTo(cx + j * W * 0.018, horizon); ctx.lineTo(cx + j * W * 0.14, H); }
            ctx.stroke();
            if (p && p.y > horizon) {
                const fg = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, H * 0.18);
                fg.addColorStop(0, 'rgba(160,90,255,.22)'); fg.addColorStop(1, 'rgba(180,100,255,0)');
                ctx.fillStyle = fg; ctx.fillRect(p.x - H * 0.18, p.y - H * 0.18, H * 0.36, H * 0.36);
            }
            // drifting particles that react to the pointer
            for (const q of parts) {
                if (p) {
                    const dx = q.x - p.x, dy = q.y - p.y, d = Math.hypot(dx, dy);
                    if (d < 160 * k) { const f = (1 - d / (160 * k)) * 600 * k * dt; q.vx += dx / (d || 1) * f; q.vy += dy / (d || 1) * f; q.glow = 1; }
                }
                q.glow = Math.max(0, q.glow - dt * 1.5);
                q.vx *= Math.exp(-dt * 1.2); q.vy += (-25 * k - q.vy) * dt * 0.8;
                q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.spin * dt;
                if (q.y < -20 || q.x < -30 || q.x > W + 30) newPart(q, false);
                const a = 0.17 + q.glow * 0.65, r = q.r * (1 + q.glow);
                ctx.fillStyle = `rgba(${q.col},${(a * 0.25).toFixed(2)})`; dot(q.x, q.y, r * 3.5);
                ctx.fillStyle = `rgba(${q.col},${a.toFixed(2)})`;
                if (q.kind === 'plus') {
                    ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.rot);
                    ctx.fillRect(-r * 2.4, -r * 0.8, r * 4.8, r * 1.6); ctx.fillRect(-r * 0.8, -r * 2.4, r * 1.6, r * 4.8);
                    ctx.restore();
                } else if (q.kind === 'ring') {
                    ctx.strokeStyle = `rgba(${q.col},${a.toFixed(2)})`; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(q.x, q.y, r * 2.2, 0, TAU); ctx.stroke();
                } else dot(q.x, q.y, r);
            }
            // glow behind the emblem
            const g1 = has ? 0.27 + beat * 0.3 + hover * 0.35 : 0;
            const halo = ctx.createRadialGradient(cx, cy, L * 0.1, cx, cy, L * (1.05 + beat * 0.12 + hover * 0.2));
            halo.addColorStop(0, `rgba(150,70,255,${(0.45 * g1).toFixed(2)})`); halo.addColorStop(0.45, `rgba(80,90,255,${(0.18 * g1).toFixed(2)})`); halo.addColorStop(1, 'rgba(80,90,255,0)');
            if (has) { ctx.fillStyle = halo; ctx.fillRect(cx - L * 1.5, cy - L * 1.5, L * 3, L * 3); }
            // rotating rings
            ctx.lineCap = 'round';
            for (let i = 0; i < (has ? 3 : 0); i++) {
                const R = L * (0.62 + i * 0.09 + hover * 0.05), dir = i % 2 ? -1 : 1, segs = 3 + i;
                ctx.strokeStyle = `rgba(${COLS[i]},${(0.35 + hover * 0.3).toFixed(2)})`; ctx.lineWidth = 2 + (2 - i);
                for (let sgi = 0; sgi < segs; sgi++) {
                    const a = t * (0.4 + i * 0.25) * dir + sgi * TAU / segs;
                    ctx.beginPath(); ctx.arc(cx, cy, R, a, a + TAU / segs * 0.55); ctx.stroke();
                }
            }
            // shockwaves
            for (let i = waves.length - 1; i >= 0; i--) {
                const w = waves[i];
                w.life -= dt; w.r += dt * L * 0.9;
                if (w.life <= 0) { waves.splice(i, 1); continue; }
                const a = w.life / w.max;
                ctx.strokeStyle = `rgba(170,100,255,${(a * 0.6).toFixed(2)})`; ctx.lineWidth = w.w * (0.5 + a);
                ctx.beginPath(); ctx.arc(w.x, w.y, w.r, 0, TAU); ctx.stroke();
            }
            // energy bolts
            ctx.lineJoin = 'round';
            for (let i = bolts.length - 1; i >= 0; i--) {
                const b = bolts[i];
                b.life -= dt;
                if (b.life <= 0) { bolts.splice(i, 1); continue; }
                const a = b.life / b.max;
                for (const [lw, col, al] of [[10, '150,60,255', 0.12], [4, '190,120,255', 0.4], [1.6, '245,230,255', 0.9]]) {
                    ctx.strokeStyle = `rgba(${col},${(al * a).toFixed(2)})`; ctx.lineWidth = lw * (b.w || 1);
                    ctx.beginPath(); ctx.moveTo(b.pts[0][0], b.pts[0][1]);
                    for (let j = 1; j < b.pts.length; j++) ctx.lineTo(b.pts[j][0], b.pts[j][1]);
                    ctx.stroke();
                }
            }
            // the emblem: pulse, bloom, pop-out on hover
            ctx.globalCompositeOperation = 'source-over';
            let sc = (1 + beat * 0.04) * (1 + hover * 0.12), la = 1;
            if (boomT >= 0) {           // a big springy pulse when clicked
                const tb = boomT;
                sc *= tb < 0.12 ? 1 + 0.28 * (tb / 0.12) : 1 + 0.28 * Math.exp(-(tb - 0.12) * 4.5) * Math.cos((tb - 0.12) * 13);
            }
            if (has && la > 0.05) {
                ctx.fillStyle = `rgba(0,0,0,${(0.35 * la).toFixed(2)})`;
                ctx.beginPath(); ctx.ellipse(cx, cy + L * 0.52 * sc, L * 0.38 * sc, L * 0.06, 0, 0, TAU); ctx.fill();
            }
            if (la > 0.01) drawLogo(sc, la);
            ctx.globalCompositeOperation = 'lighter';
            if (la > 0.01) {
                drawLogo(sc * (1.04 + beat * 0.02), (0.14 + beat * 0.15 + hover * 0.15) * la);
                drawLogo(sc * (1.1 + beat * 0.04), (0.05 + beat * 0.08 + hover * 0.08) * la);
            }
            // sparks and pointer trail
            for (let i = sparks.length - 1; i >= 0; i--) {
                const s = sparks[i];
                s.life -= dt;
                if (s.life <= 0) { sparks.splice(i, 1); continue; }
                if (s.curl) {
                    const c = Math.cos(s.curl * dt), sn = Math.sin(s.curl * dt), vx = s.vx;
                    s.vx = vx * c - s.vy * sn; s.vy = vx * sn + s.vy * c;
                }
                s.vx *= Math.exp(-dt * 1.8); s.vy *= Math.exp(-dt * 1.8);
                const ox = s.x, oy = s.y;
                s.x += s.vx * dt; s.y += s.vy * dt;
                if (s.curl) {
                    const a2 = s.life / s.max;
                    ctx.strokeStyle = `rgba(${s.col},${(a2 * 0.5).toFixed(1)})`; ctx.lineWidth = s.r * 1.4;
                    ctx.beginPath(); ctx.moveTo(ox - s.vx * 0.04, oy - s.vy * 0.04); ctx.lineTo(s.x, s.y); ctx.stroke();
                }
                const a = s.life / s.max;
                ctx.fillStyle = `rgba(${s.col},${(a * 0.3).toFixed(2)})`; dot(s.x, s.y, s.r * 3);
                ctx.fillStyle = `rgba(235,220,255,${a.toFixed(2)})`; dot(s.x, s.y, s.r * 0.8);
            }
            ctx.lineCap = 'round';
            for (let i = trail.length - 1; i >= 0; i--) {
                const q = trail[i];
                q.life -= dt;
                if (q.life <= 0) { trail.splice(i, 1); continue; }
                q.vy += 700 * k * dt; q.vx *= Math.exp(-dt * 2);
                q.x += q.vx * dt; q.y += q.vy * dt;
                const a = q.life / q.max, tx = q.x - q.vx * 0.035, ty = q.y - q.vy * 0.035;
                ctx.strokeStyle = `rgba(${q.col},${(a * 0.35).toFixed(1)})`; ctx.lineWidth = 2.4;
                ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(tx, ty); ctx.stroke();
                ctx.strokeStyle = `rgba(245,235,255,${(a * 0.8).toFixed(1)})`; ctx.lineWidth = 0.9;
                ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(tx, ty); ctx.stroke();
            }
            if (p) {
                const cg = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 26);
                cg.addColorStop(0, 'rgba(200,150,255,.2)'); cg.addColorStop(1, 'rgba(200,150,255,0)');
                ctx.fillStyle = cg; ctx.fillRect(p.x - 26, p.y - 26, 52, 52);
            }
            if (flash > 0.02) { ctx.fillStyle = `rgba(170,90,255,${(flash * 0.22).toFixed(2)})`; ctx.fillRect(0, 0, W, H); }
            ctx.globalCompositeOperation = 'source-over';
        }
        return {init, frame};
    })();

    /* Floating orbs: shimmering soap bubbles and bokeh lights, with optional wallpaper behind */
    const orbs = (() => {
        let O = [], bgL = null, t = 0, minR = 0, maxR = 0;
        const COL = [['80,255,170', 3], ['255,90,200', 3], ['170,90,255', 3], ['60,210,220', 2], ['255,150,90', 2]];
        // soap-film colours used around each bubble's rim
        const IRIS = ['255,120,200', '255,170,90', '255,235,140', '120,255,190', '90,210,255', '150,130,255', '220,110,255', '255,120,160'];
        let glitter = [];
        const totalW = COL.reduce((a, c) => a + c[1], 0);
        const pickCol = () => { let r = Math.random() * totalW; for (const [c, w] of COL) { if ((r -= w) < 0) return c; } return COL[0][0]; };
        function mk() {
            const a = rand(0, TAU);
            return {x: rand(0, W), y: rand(0, H), vx: Math.cos(a) * 20, vy: Math.sin(a) * 20, a, z: rand(0, 1), zt: rand(0, 1), zT: rand(2, 10),
                col: pickCol(), ring: Math.random() < 0.6, ph: rand(0, TAU), sp: rand(45, 110), spin: rand(-0.4, 0.4)};
        }
        function init() {
            t = 0; minR = H * 0.008; maxR = H * 0.075;
            bgL = makeLayer(W, H, env.rs);
            const g = bgL.ctx;
            const sky = g.createLinearGradient(0, 0, W, H);
            sky.addColorStop(0, '#04121e'); sky.addColorStop(0.5, '#0a0a24'); sky.addColorStop(1, '#10061e');
            g.fillStyle = sky; g.fillRect(0, 0, W, H);
            g.globalCompositeOperation = 'lighter';
            for (const [x, y, r, c, a] of [[W * 0.85, H * 0.15, 0.5, '255,140,120', 0.1], [W * 0.75, H * 0.3, 0.35, '255,90,200', 0.08], [W * 0.4, H * 0.55, 0.45, '40,200,200', 0.08], [W * 0.1, H * 0.8, 0.4, '120,80,255', 0.07]]) {
                const R = r * Math.max(W, H);
                const gr = g.createRadialGradient(x, y, 0, x, y, R);
                gr.addColorStop(0, `rgba(${c},${a})`); gr.addColorStop(1, `rgba(${c},0)`);
                g.fillStyle = gr; g.fillRect(x - R, y - R, R * 2, R * 2);
            }
            for (let i = 0; i < 10; i++) {
                const x = rand(0, W), y = rand(0, H), r = rand(0.15, 0.4) * Math.max(W, H), c = pickCol();
                const gr = g.createRadialGradient(x, y, 0, x, y, r);
                gr.addColorStop(0, `rgba(${c},.04)`); gr.addColorStop(1, `rgba(${c},0)`);
                g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
            }
            g.globalCompositeOperation = 'source-over';
            const n = Math.round(Math.max(40, Math.min(95, W * H / 24000)));
            O = Array.from({length: n}, mk);
            glitter = Array.from({length: Math.round(W * H / 9000)}, () => ({x: rand(0, W), y: rand(0, H), ph: rand(0, TAU), sp: rand(1, 3), vy: -rand(3, 12), c: IRIS[(Math.random() * IRIS.length) | 0]}));
        }
        function background() {
            const img = env.wall;
            if (!img) { ctx.drawImage(bgL, 0, 0); return; }
            const s2 = Math.max(W / img.w, H / img.h), w = img.w * s2, h = img.h * s2;
            ctx.fillStyle = '#000000'; ctx.fillRect(0, 0, W, H);
            ctx.drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
            // blend it into the theme: darken, then wash it with the theme's colours
            const dim = (env.opts.orbsDim ?? 45) / 100;
            ctx.fillStyle = `rgba(8,3,26,${dim.toFixed(2)})`; ctx.fillRect(0, 0, W, H);
            ctx.globalAlpha = 0.5; ctx.drawImage(bgL, 0, 0); ctx.globalAlpha = 1;
        }
        function frame(dt) {
            t += dt;
            const k = H / 1080, p = env.pointer;
            const focus = 0.45 + Math.sin(t * 0.07) * 0.18;
            for (const o of O) {
                // wander, with nearer orbs drifting faster (parallax)
                o.a += rand(-1, 1) * dt * 1.3;
                const sp = o.sp * k * (0.4 + o.z * 1.2);
                o.vx += (Math.cos(o.a) * sp - o.vx) * dt * 0.9;
                o.vy += (Math.sin(o.a) * sp - o.vy) * dt * 0.9;
                // shy of the mouse
                if (p) {
                    const dx = o.x - p.x, dy = o.y - p.y, d = Math.hypot(dx, dy) || 1, R = 260 * k * (0.6 + o.z);
                    if (d < R) { const f = (1 - d / R) * 4200 * k * dt * (0.5 + o.z); o.vx += dx / d * f; o.vy += dy / d * f; }
                }
                const vmax = 900 * k;
                const v = Math.hypot(o.vx, o.vy);
                if (v > vmax) { o.vx *= vmax / v; o.vy *= vmax / v; }
                o.x += o.vx * dt; o.y += o.vy * dt;
                // bounce off the edges and corners of the screen
                const r = minR + (maxR - minR) * Math.pow(o.z, 1.4);
                if (o.x < r) { o.x = r; o.vx = Math.abs(o.vx); o.a = Math.PI - o.a; }
                if (o.x > W - r) { o.x = W - r; o.vx = -Math.abs(o.vx); o.a = Math.PI - o.a; }
                if (o.y < r) { o.y = r; o.vy = Math.abs(o.vy); o.a = -o.a; }
                if (o.y > H - r) { o.y = H - r; o.vy = -Math.abs(o.vy); o.a = -o.a; }
                // drift closer and further away
                o.zT -= dt;
                if (o.zT <= 0) { o.zt = rand(0, 1); o.zT = rand(4, 12); }
                o.z += (o.zt - o.z) * dt * 0.22;
            }
            O.sort((a, b) => a.z - b.z);
            background();
            ctx.globalCompositeOperation = 'lighter';
            // glitter drifting in the light
            for (const g of glitter) {
                g.y += g.vy * k * dt;
                if (g.y < -4) { g.y = H + 4; g.x = rand(0, W); }
                const tw = Math.max(0, Math.sin(t * g.sp + g.ph));
                if (tw < 0.2) continue;
                ctx.fillStyle = `rgba(${g.c},${(tw * 0.7).toFixed(2)})`; dot(g.x, g.y, 0.8 + tw * 0.8);
            }
            for (const o of O) {
                const r = minR + (maxR - minR) * Math.pow(o.z, 1.4);
                const b = Math.min(1, Math.abs(o.z - focus) * 2.4);      // 0 = sharp, 1 = blurred
                const a = (0.5 + 0.5 * (1 - b)) * (0.45 + 0.55 * o.z) * (0.88 + 0.12 * Math.sin(t * 1.3 + o.ph));
                // out of focus: a soft, flat bokeh disc in the orb's colour
                const bok = o.ring ? Math.max(0, (b - 0.35) / 0.65) : 1;
                if (bok > 0.02) {
                    const R = r * (1 + b * 0.4);
                    const gr = ctx.createRadialGradient(o.x, o.y, 0, o.x, o.y, R);
                    const fa = (0.3 - 0.12 * b) * a * bok;
                    gr.addColorStop(0, `rgba(${o.col},${(fa * 0.8).toFixed(3)})`);
                    gr.addColorStop(0.82, `rgba(${o.col},${fa.toFixed(3)})`);
                    gr.addColorStop(1, `rgba(${o.col},0)`);
                    ctx.fillStyle = gr; ctx.fillRect(o.x - R, o.y - R, R * 2, R * 2);
                }
                // in focus: a glassy soap bubble with a rainbow rim and highlights
                const bub = o.ring ? 1 - bok : 0;
                if (bub < 0.02) continue;
                const ba = a * bub;
                const inner = ctx.createRadialGradient(o.x - r * 0.2, o.y - r * 0.25, r * 0.1, o.x, o.y, r);
                inner.addColorStop(0, `rgba(90,210,255,${(0.05 * ba).toFixed(3)})`);
                inner.addColorStop(0.8, `rgba(${o.col},${(0.1 * ba).toFixed(3)})`);
                inner.addColorStop(1, `rgba(255,255,255,${(0.22 * ba).toFixed(3)})`);
                ctx.fillStyle = inner; dot(o.x, o.y, r);
                const segs = IRIS.length, rot = o.ph + t * o.spin;
                ctx.lineCap = 'round';
                for (const [lw, al] of [[r * 0.16, 0.18], [Math.max(1, r * 0.055), 0.75]]) {
                    ctx.lineWidth = lw;
                    for (let i = 0; i < segs; i++) {
                        const a0 = rot + i * TAU / segs;
                        ctx.strokeStyle = `rgba(${IRIS[i]},${(al * ba).toFixed(3)})`;
                        ctx.beginPath(); ctx.arc(o.x, o.y, r * 0.95, a0, a0 + TAU / segs + 0.02); ctx.stroke();
                    }
                }
                // warm reflection along the lower inside edge
                ctx.strokeStyle = `rgba(255,170,110,${(0.4 * ba).toFixed(3)})`; ctx.lineWidth = Math.max(1, r * 0.07);
                ctx.beginPath(); ctx.arc(o.x, o.y, r * 0.8, Math.PI * 0.15, Math.PI * 0.75); ctx.stroke();
                // window highlight and a small second glint
                ctx.fillStyle = `rgba(255,255,255,${(0.75 * ba).toFixed(3)})`;
                ctx.beginPath(); ctx.ellipse(o.x - r * 0.38, o.y - r * 0.42, r * 0.2, r * 0.11, -0.7, 0, TAU); ctx.fill();
                ctx.fillStyle = `rgba(255,255,255,${(0.45 * ba).toFixed(3)})`; dot(o.x + r * 0.45, o.y + r * 0.38, r * 0.06);
                // a twinkling star on the sharpest bubbles
                if (b < 0.2) {
                    const tw = Math.max(0, Math.sin(t * 2.2 + o.ph * 3)), L2 = r * 0.35 * tw;
                    if (tw > 0.1) {
                        const sx = o.x - r * 0.25, sy = o.y - r * 0.1;
                        ctx.strokeStyle = `rgba(255,255,255,${(0.8 * tw * ba).toFixed(2)})`; ctx.lineWidth = 1;
                        ctx.beginPath(); ctx.moveTo(sx - L2, sy); ctx.lineTo(sx + L2, sy); ctx.moveTo(sx, sy - L2); ctx.lineTo(sx, sy + L2); ctx.stroke();
                    }
                }
            }
            ctx.globalCompositeOperation = 'source-over';
        }
        return {init, frame};
    })();

    /* Fireflies in a night forest, with a campfire */
    const fireflies = (() => {
        let F = [], E = [], backL = null, nearL = null, fire = null, t = 0, burst = 3;
        const glow = makeLayer(64, 64);
        const gr = glow.ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
        gr.addColorStop(0, 'rgba(255,248,180,1)'); gr.addColorStop(0.18, 'rgba(225,255,120,.7)'); gr.addColorStop(1, 'rgba(150,255,80,0)');
        glow.ctx.fillStyle = gr; glow.ctx.fillRect(0, 0, 64, 64);
        const disc = (g, x, y, r) => { g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); };

        // Conifer: stacked tiers with ragged, drooping edges.
        function pine(g, x, base, h) {
            g.fillRect(x - h * 0.018, base - h * 0.12, h * 0.036, h * 0.14);
            const tiers = 9, teeth = 4;
            for (let k = 0; k < tiers; k++) {
                const f = k / tiers;
                const y0 = base - h * 0.08 - f * h * 0.8;
                const half = h * 0.26 * (1 - f * 0.85);
                const top = y0 - h * 0.2 * (1 - f * 0.4);
                g.beginPath();
                g.moveTo(x, top);
                g.lineTo(x - half, y0 + h * 0.015);
                for (let i = 1; i <= teeth * 2; i++) {
                    const px = x - half + 2 * half * i / (teeth * 2);
                    const py = i % 2 ? y0 - h * 0.03 : y0 + h * 0.012 * rand(0.5, 1.5);
                    g.lineTo(px, py);
                }
                g.closePath();
                g.fill();
            }
        }

        // Broadleaf: a branching trunk with leafy clusters at the tips.
        function branch(g, x, y, ang, len, w, depth) {
            const x2 = x + Math.cos(ang) * len, y2 = y + Math.sin(ang) * len;
            g.lineWidth = Math.max(0.8, w);
            g.beginPath(); g.moveTo(x, y); g.lineTo(x2, y2); g.stroke();
            if (depth <= 1) {
                // Leafy clump around the twig tips; overlapping blobs make a soft canopy edge.
                const k = depth <= 0 ? 7 : 4;
                for (let i = 0; i < k; i++) {
                    g.beginPath();
                    g.ellipse(x2 + rand(-1, 1) * len * 0.9, y2 + rand(-1.1, 0.5) * len * 0.9, len * rand(0.45, 0.95), len * rand(0.35, 0.7), rand(0, TAU), 0, TAU);
                    g.fill();
                }
                if (depth <= 0 || len < 3)
                    return;
            }
            const n = Math.random() < 0.3 ? 3 : 2;
            for (let i = 0; i < n; i++) {
                const spread = n === 2 ? (i ? 1 : -1) * rand(0.25, 0.6) : (i - 1) * rand(0.35, 0.6);
                branch(g, x2, y2, ang + spread + rand(-0.12, 0.12), len * rand(0.66, 0.8), w * 0.68, depth - 1);
            }
        }
        function broadleaf(g, x, base, h, depth) {
            g.lineCap = 'round';
            branch(g, x, base, -Math.PI / 2 + rand(-0.06, 0.06), h * 0.28, h * 0.06, depth);
        }

        // A person sitting on a stump, leaning toward the fire (dir = +1 faces right).
        function seated(g, x, base, s, dir) {
            g.lineCap = 'round';
            g.fillRect(x - s * 0.26, base - s * 0.2, s * 0.5, s * 0.2);
            const hipY = base - s * 0.26;
            g.lineWidth = s * 0.12;
            g.beginPath(); g.moveTo(x, hipY); g.lineTo(x + dir * s * 0.3, base - s * 0.36); g.lineTo(x + dir * s * 0.36, base); g.stroke();
            g.lineWidth = s * 0.24;
            g.beginPath(); g.moveTo(x - dir * s * 0.02, hipY); g.lineTo(x + dir * s * 0.05, base - s * 0.68); g.stroke();
            disc(g, x + dir * s * 0.09, base - s * 0.79, s * 0.105);
            g.lineWidth = s * 0.07;
            g.beginPath(); g.moveTo(x + dir * s * 0.05, base - s * 0.66); g.lineTo(x + dir * s * 0.08, base - s * 0.74); g.stroke();
            g.lineWidth = s * 0.08;
            g.beginPath(); g.moveTo(x + dir * s * 0.06, base - s * 0.64); g.lineTo(x + dir * s * 0.28, base - s * 0.44); g.lineTo(x + dir * s * 0.42, base - s * 0.52); g.stroke();
        }

        function init() {
            t = 0; E = []; burst = rand(2, 5);
            const gy = H * 0.95;
            fire = {x: W * 0.5 + rand(-W * 0.08, W * 0.08), base: H * 0.968, s: Math.max(9, H * 0.027)};

            backL = makeLayer(W, H, env.rs);
            let g = backL.ctx;
            const sky = g.createLinearGradient(0, 0, 0, H);
            sky.addColorStop(0, '#02040d'); sky.addColorStop(0.65, '#0a1430'); sky.addColorStop(1, '#101c38');
            g.fillStyle = sky; g.fillRect(0, 0, W, H);
            const ns = Math.round(W * H / 6000);
            for (let i = 0; i < ns; i++) {
                g.fillStyle = `rgba(255,255,255,${rand(0.2, 0.9).toFixed(2)})`;
                const sz = rand(0.6, 1.6);
                g.fillRect(rand(0, W), rand(0, H * 0.65), sz, sz);
            }
            const mx = W * 0.8, my = H * 0.18, mr = Math.max(14, Math.min(W, H) * 0.045);
            const halo = g.createRadialGradient(mx, my, mr, mx, my, mr * 5);
            halo.addColorStop(0, 'rgba(220,225,255,.18)'); halo.addColorStop(1, 'rgba(220,225,255,0)');
            g.fillStyle = halo; g.fillRect(mx - mr * 5, my - mr * 5, mr * 10, mr * 10);
            g.fillStyle = '#efe9d2'; disc(g, mx, my, mr);
            g.fillStyle = 'rgba(0,0,0,.08)';
            for (const [dx, dy, r] of [[-0.3, -0.2, 0.22], [0.25, 0.1, 0.18], [-0.05, 0.35, 0.12]]) disc(g, mx + dx * mr, my + dy * mr, r * mr);

            // Distant treeline
            g.fillStyle = '#0b1526'; g.strokeStyle = '#0b1526';
            const base = H * 0.8;
            let x = -40;
            while (x < W + 60) {
                const h = H * rand(0.16, 0.32);
                if (Math.random() < 0.65) pine(g, x, base + rand(0, 10), h);
                else broadleaf(g, x, base + rand(0, 10), h * 1.1, 5);
                x += rand(25, 70);
            }
            g.fillRect(0, base, W, H - base);

            // Foreground trees, ground, campers
            nearL = makeLayer(W, H, env.rs);
            g = nearL.ctx;
            g.fillStyle = '#010302'; g.strokeStyle = '#010302';
            x = rand(-80, 40);
            while (x < W + 100) {
                if (Math.abs(x - fire.x) > W * 0.14) {
                    const h = H * rand(0.5, 0.85);
                    if (Math.random() < 0.5) pine(g, x, H + 5, h);
                    else broadleaf(g, x, H + 5, h, 7);
                }
                x += rand(180, 360);
            }
            g.fillRect(0, gy, W, H - gy + 2);
            g.lineWidth = 1.5; g.lineCap = 'round';
            g.beginPath();
            for (let gx = 0; gx < W; gx += 3) { g.moveTo(gx, gy + 2); g.lineTo(gx + rand(-3, 3), gy - rand(3, 11)); }
            g.stroke();

            const ps = H * 0.1, fs = fire.s;
            seated(g, fire.x - fs * 4.2, fire.base, ps, 1);
            seated(g, fire.x - fs * 7.6, fire.base + 2, ps * 1.06, 1);
            seated(g, fire.x + fs * 4.4, fire.base, ps * 0.96, -1);

            g.strokeStyle = '#140a05'; g.lineWidth = fs * 0.3; g.lineCap = 'round';
            g.beginPath();
            g.moveTo(fire.x - fs * 1.3, fire.base + fs * 0.1); g.lineTo(fire.x + fs * 1.1, fire.base - fs * 0.35);
            g.moveTo(fire.x + fs * 1.3, fire.base + fs * 0.1); g.lineTo(fire.x - fs * 1.1, fire.base - fs * 0.35);
            g.stroke();

            const n = Math.round(Math.max(35, Math.min(90, W * H / 20000)));
            F = Array.from({length: n}, () => {
                const far = Math.random() < 0.5;
                return {far, x: rand(0, W), y: rand(H * 0.35, H * 0.92), vx: rand(-15, 15), vy: rand(-15, 15), ph: rand(0, TAU), rate: rand(0.8, 2.2), s: rand(18, 40) * (far ? 0.6 : 1)};
            });
        }

        function flies(dt, far) {
            ctx.globalCompositeOperation = 'lighter';
            for (const f of F) {
                if (f.far !== far) continue;
                f.vx += rand(-60, 60) * dt; f.vy += rand(-60, 60) * dt;
                const p = env.pointer;
                if (p) {
                    const dx = p.x - f.x, dy = p.y - f.y;
                    const distance = Math.hypot(dx, dy) || 1;
                    const attraction = Math.max(0, 1 - distance / Math.max(160, H * 0.4));
                    f.vx += dx / distance * attraction * 160 * dt;
                    f.vy += dy / distance * attraction * 160 * dt;
                    const speed = Math.hypot(f.vx, f.vy);
                    if (speed > 140) { f.vx *= 140 / speed; f.vy *= 140 / speed; }
                    f.ph += attraction * dt * 2;
                }
                if (f.y < H * 0.3) f.vy += 40 * dt;
                if (f.y > H * 0.93) f.vy -= 40 * dt;
                const damp = 1 - Math.min(1, dt * 0.6);
                f.vx *= damp; f.vy *= damp;
                f.x += f.vx * dt; f.y += f.vy * dt;
                if (f.x < -40) f.x = W + 40;
                if (f.x > W + 40) f.x = -40;
                f.ph += f.rate * dt;
                const b = Math.pow(Math.max(0, Math.sin(f.ph)), 3);
                ctx.globalAlpha = (0.12 + b * 0.88) * (far ? 0.7 : 1);
                ctx.drawImage(glow, f.x - f.s / 2, f.y - f.s / 2, f.s, f.s);
            }
            ctx.globalAlpha = 1;
            ctx.globalCompositeOperation = 'source-over';
        }

        function drawFire() {
            const {x, base, s} = fire;
            const flick = Math.max(0.6, 0.88 + 0.12 * Math.sin(t * 13) * Math.sin(t * 7.3 + 1) + rand(-0.05, 0.05));
            ctx.globalCompositeOperation = 'lighter';
            const g = ctx.createRadialGradient(x, base - s, 0, x, base - s, s * 10);
            g.addColorStop(0, `rgba(255,140,50,${(0.4 * flick).toFixed(2)})`);
            g.addColorStop(0.35, `rgba(200,80,20,${(0.14 * flick).toFixed(2)})`);
            g.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = g;
            ctx.fillRect(x - s * 10, base - s * 11, s * 20, s * 14);
            const layers = [['rgba(255,70,20,.55)', 1, 1], ['rgba(255,150,40,.6)', 0.75, 0.72], ['rgba(255,230,140,.7)', 0.45, 0.42]];
            for (const [col, wf, hf] of layers) {
                ctx.fillStyle = col;
                for (let i = 0; i < 4; i++) {
                    const off = (i - 1.5) * s * 0.35 * wf;
                    const hh = s * 2.4 * hf * (0.75 + 0.3 * Math.sin(t * (6 + i * 1.7) + i * 2)) * flick;
                    const sway = Math.sin(t * (3 + i) + i) * s * 0.25;
                    const w = s * 0.55 * wf, cx = x + off;
                    ctx.beginPath();
                    ctx.moveTo(cx - w, base);
                    ctx.bezierCurveTo(cx - w, base - hh * 0.45, cx + sway - w * 0.2, base - hh * 0.7, cx + sway, base - hh);
                    ctx.bezierCurveTo(cx + sway + w * 0.2, base - hh * 0.7, cx + w, base - hh * 0.45, cx + w, base);
                    ctx.closePath();
                    ctx.fill();
                }
            }
            ctx.globalCompositeOperation = 'source-over';
        }

        function spawnEmber(pop) {
            const life = rand(1.5, 3.5);
            E.push({x: fire.x + rand(-0.5, 0.5) * fire.s, y: fire.base - fire.s * rand(0.5, 1.5),
                vx: rand(-20, 20) * (pop ? 2.5 : 1), vy: -rand(30, 70) * (pop ? 1.8 : 1), life, max: life, r: rand(0.8, 1.8), ph: rand(0, 6)});
        }
        function embers(dt) {
            burst -= dt;
            if (burst <= 0) {
                const n = rand(8, 20) | 0;
                for (let i = 0; i < n; i++) spawnEmber(true);
                burst = rand(2, 6);
            }
            if (Math.random() < dt * 5) spawnEmber(false);
            ctx.globalCompositeOperation = 'lighter';
            for (let i = E.length - 1; i >= 0; i--) {
                const e = E[i];
                e.life -= dt;
                if (e.life <= 0) { E.splice(i, 1); continue; }
                e.vx += rand(-40, 40) * dt; e.vy -= 10 * dt;
                e.x += e.vx * dt; e.y += e.vy * dt;
                e.ph += dt * 20;
                const a = e.life / e.max, tw = 0.6 + 0.4 * Math.sin(e.ph);
                ctx.fillStyle = `rgba(255,${(150 + a * 80) | 0},60,${(a * tw).toFixed(2)})`;
                dot(e.x, e.y, e.r);
            }
            ctx.globalCompositeOperation = 'source-over';
        }

        function frame(dt) {
            t += dt;
            ctx.drawImage(backL, 0, 0);
            flies(dt, true);
            ctx.drawImage(nearL, 0, 0);
            drawFire();
            embers(dt);
            flies(dt, false);
            const p = env.pointer;
            if (p) {
                const size = Math.max(60, H * 0.14);
                ctx.globalCompositeOperation = 'lighter';
                ctx.globalAlpha = 0.5;
                ctx.drawImage(glow, p.x - size / 2, p.y - size / 2, size, size);
                ctx.globalAlpha = 1;
                ctx.globalCompositeOperation = 'source-over';
            }
        }
        return {init, frame};
    })();

    return {matrix, code, storm, cyclone: storm, starfield, fireflies,
        neon, 'neon-bazzite': neon, orbs, 'orbs-bazzite': orbs};
}

class Engine {
    constructor(width, height, rs = 1) {
        this.W = width;
        this.H = height;
        this.rs = rs;
        this.main = makeLayer(width, height, rs);
        this.ctx = this.main.ctx;
        this.pointer = null;
        this.logo = null;
        this.wall = null;
        this.opts = {};
        this.themes = makeThemes(this);
        this.current = null;
    }

    setTheme(id) {
        this.current = this.themes[id] ?? this.themes.matrix;
        this.ctx.globalAlpha = 1;
        this.ctx.globalCompositeOperation = 'source-over';
        this.current.init();
    }

    setLogo(logo) {
        this.logo = logo;
    }

    setWallpaper(img) {
        this.wall = img;
    }

    setOption(key, value) {
        this.opts[key] = value;
    }

    step(dt, pointer) {
        this.pointer = pointer;
        this.current?.frame(dt);
    }

    paint(cr) {
        cr.drawImage(this.main.canvas, 0, 0);
    }

    destroy() {
        this.current = null;
        this.themes = null;
        try {
            this.main.canvas.width = 1;
            this.main.canvas.height = 1;
        } catch (e) {}
    }
}

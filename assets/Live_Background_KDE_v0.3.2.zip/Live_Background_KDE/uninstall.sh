#!/usr/bin/env bash
set -euo pipefail
plugin_id="org.steamdeckchecker.livebackground"
config_file="${XDG_CONFIG_HOME:-$HOME/.config}/plasma-org.kde.plasma.desktop-appletsrc"

if [[ -f "$config_file" ]]; then
    while IFS= read -r line; do
        if [[ $line == "wallpaperplugin=$plugin_id" ]]; then
            echo "Bitte zuerst für alle Bildschirme und Aktivitäten ein anderes Hintergrundbild auswählen."
            echo "Danach bash uninstall.sh erneut ausführen."
            exit 1
        fi
    done < "$config_file"
fi
if ! command -v kpackagetool6 >/dev/null 2>&1; then
    echo "kpackagetool6 wurde nicht gefunden." >&2
    exit 1
fi
kpackagetool6 --type Plasma/Wallpaper --remove "$plugin_id"
echo "Live Background (KDE) wurde entfernt."

#!/usr/bin/env bash
set -euo pipefail

plugin_id="org.steamdeckchecker.livebackground"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
plugin_source="$script_dir/$plugin_id"
plugin_root="${XDG_DATA_HOME:-$HOME/.local/share}/plasma/wallpapers"
plugin_destination="$plugin_root/$plugin_id"

if [[ ${EUID:-$(id -u)} -eq 0 && ${LIVE_BACKGROUND_INSTALL_TEST:-0} != 1 ]]; then
    echo "Bitte als normaler Benutzer ausführen: bash install.sh (ohne sudo)." >&2
    exit 1
fi
if ! command -v kpackagetool6 >/dev/null 2>&1; then
    echo "kpackagetool6 fehlt. Dieses Paket benötigt KDE Plasma 6." >&2
    exit 1
fi
if command -v plasmashell >/dev/null 2>&1; then
    plasma_version="$(plasmashell --version 2>/dev/null)"
    if [[ $plasma_version != *" 6."* ]]; then
        echo "Dieses Paket benötigt Plasma 6. Gefunden: $plasma_version" >&2
        exit 1
    fi
fi
if command -v rpm >/dev/null 2>&1 && ! rpm -q qt6-qtwebengine >/dev/null 2>&1; then
    echo "QtWebEngine fehlt. Unter Bazzite bitte einmal ausführen:" >&2
    echo "  sudo rpm-ostree install qt6-qtwebengine" >&2
    echo "Danach neu starten und bash install.sh erneut ausführen." >&2
    exit 1
fi
if [[ ! -f "$plugin_source/metadata.json" || ! -f "$plugin_source/contents/web/engine.js" || ! -f "$plugin_source/contents/ui/ThemeRotation.qml" ]]; then
    echo "Das Paket ist unvollständig. Bitte die ganze ZIP-Datei entpacken." >&2
    exit 1
fi

# --show also accepts a local source directory. When run from this package's
# folder it reports that directory, even before the wallpaper is installed.
# Check the actual per-user installation instead and use that same root for
# the subsequent operation.
if [[ -f "$plugin_destination/metadata.json" ]]; then
    kpackagetool6 --type Plasma/Wallpaper --packageroot "$plugin_root" --upgrade "$plugin_source"
else
    kpackagetool6 --type Plasma/Wallpaper --packageroot "$plugin_root" --install "$plugin_source"
fi
if [[ ! -f "$plugin_destination/metadata.json" || ! -f "$plugin_destination/contents/ui/main.qml" ]]; then
    echo "Die Installation wurde nicht im erwarteten Zielordner gefunden: $plugin_destination" >&2
    exit 1
fi

cat <<'TEXT'

Live Background (KDE) ist installiert.

1. Rechtsklick auf den Desktop → Arbeitsfläche und Hintergrundbild einrichten.
2. Bei Hintergrundbildtyp „Live Background (KDE)“ auswählen.
3. Motiv auswählen und auf Anwenden klicken.

Falls der Eintrag fehlt: Einstellungsfenster schließen und erneut öffnen.
Falls nötig: einmal abmelden und wieder anmelden.

WICHTIG nach einer Aktualisierung: Einmal abmelden und wieder anmelden.
Erst danach die neuen Einstellungen öffnen. Plasma muss den geänderten
QML-Code und die Konfiguration neu laden; bloßes Neu-Auswählen reicht
bei einem bereits laufenden Hintergrund nicht immer aus.

Startempfehlung: 24 FPS und 60 % Renderauflösung.
TEXT

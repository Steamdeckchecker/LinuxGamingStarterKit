# Live Background für KDE Plasma 6 – Version 0.3.2

KDE-Anpassung der Animationen aus https://github.com/ryth9419-jpg/livewallpaper.
Die GNOME-Shell-Erweiterung wird durch ein Plasma-Hintergrundmodul ersetzt.
Die Animationen laufen lokal über Canvas 2D in QtWebEngine.

## Installation unter Bazzite KDE

1. Die ZIP-Datei vollständig entpacken, zum Beispiel nach `Downloads/Live_Background_KDE`.
2. Den entpackten Ordner im Dateimanager öffnen.
3. Rechtsklick auf eine freie Stelle → „Im Terminal öffnen“.
4. Ohne sudo ausführen:

   ```bash
   bash install.sh
   ```

5. Rechtsklick auf den Desktop → „Arbeitsfläche und Hintergrundbild einrichten“.
6. Unter „Hintergrundbildtyp“ **Live Background (KDE)** auswählen.
7. Motiv wählen und **Anwenden** anklicken.

Wenn der Eintrag nicht erscheint, das Einstellungsfenster schließen und erneut
öffnen. Bei Bedarf einmal abmelden und wieder anmelden.

### Aktualisierung von 0.3.1 oder älter

1. Das Einstellungsfenster für den Hintergrund schließen.
2. Diese ZIP in einen neuen Ordner entpacken und dort `bash install.sh` ausführen.
3. **Einmal abmelden und wieder anmelden.** Dabei werden der QML-Code und das
   Konfigurationsschema neu geladen. Nur ein anderes Motiv zu wählen, reicht
   bei einem bereits geladenen Modul nicht immer aus.
4. Den Hintergrunddialog erneut öffnen, eines der neuen Bazzite-Motive oder
   den **Zufallsmodus** wählen und **Anwenden** anklicken.

Die Version **0.3.2** steht unten im Einstellungsbereich. Wird dort noch eine
ältere Version angezeigt, läuft noch der alte Code. Beim Test die manuelle
Pause ausschalten und kein Vollbildfenster geöffnet lassen.

### Neu in 0.3.2

- **Neon-Emblem-SDC** entspricht dem bisherigen Neon-Emblem mit dem
  Steam-Deck-Checker-Logo.
- **Neon-Emblem-Bazzite** verwendet das mitgelieferte Bazzite-Logo als SVG
  mit transparentem Hintergrund.
- **Schwebende Blasen SDC** entspricht den bisherigen schwebenden Kugeln
  mit der Steam-Deck-Checker-Spielecollage.
- **Schwebende Blasen Bazzite** verwendet das mitgelieferte Bazzite-Wallpaper.
- Alle neun Motive stehen auch im Zufallsmodus und in der Browser-Vorschau
  zur Verfügung. Eigene Logos und Hintergrundbilder werden für SDC und
  Bazzite getrennt gespeichert; „Standardlogo“ bzw. „Standardbild“ stellt
  das mitgelieferte Bild der jeweiligen Variante wieder her.
- Die bisherigen Motivkennungen und SDC-Bildeinstellungen bleiben erhalten.
  Eine bestehende Auswahl von Neon-Emblem oder schwebenden Kugeln wird daher
  automatisch als die entsprechende SDC-Variante weiterverwendet.

### Korrekturen in 0.3.1

- Mausbewegungen werden an der gemeinsamen Fensterebene beobachtet, statt
  unter der Desktop-Ordneransicht. Maus-/Touchkontakte werden von einer
  transparenten, passiven Eingabeebene beobachtet. Desktop-Symbole, deren
  Hover-Verhalten, Auswahlrahmen und Rechtsklick bleiben bedienbar.
- Der Hintergrunddialog nimmt die von Plasma übergebenen Eigenschaften an
  und meldet Änderungen ausdrücklich zurück. Das Minutenfeld aktualisiert
  den gespeicherten Wert auch beim direkten Eintippen; **Anwenden** erkennt
  eine reine Intervalländerung.
- Ein nativer Qt-Timer steuert den Zufallswechsel im Plasma-Modul. Der
  Wechsel hängt damit nicht von JavaScript-Timern im Hintergrund-Webplayer
  ab. Die Browser-Vorschau verwendet weiterhin ihren eigenen Web-Timer.

### Installer-Korrektur vom 05.11.2026

Der Installer prüft jetzt den tatsächlich installierten Zielordner. In der
ersten Ausgabe konnte der entpackte Quellenordner als bereits installiert
erkannt werden; dadurch wurde fälschlich eine Aktualisierung gestartet.
Das führte bei der ersten Installation zur Meldung „Das Modul … ist nicht
installiert“.

Wer diese Meldung mit dem ursprünglichen Installer erhält, kann im bereits
entpackten Ordner direkt installieren:

```bash
kpackagetool6 --type Plasma/Wallpaper --install "$PWD/org.steamdeckchecker.livebackground"
```

Die vorliegende ZIP enthält den korrigierten Installer.

Das Installationsskript prüft die Voraussetzungen. Falls QtWebEngine fehlt,
zeigt es diesen Bazzite-Befehl an:

```bash
sudo rpm-ostree install qt6-qtwebengine
```

Anschließend neu starten und `bash install.sh` erneut ausführen.
Der Paketmanager übernimmt dabei die Abhängigkeiten. Das Installationsskript
installiert selbst keine Systempakete.

## Motive und Einstellungen

Enthalten sind Matrix-Regen, Code-Stream, Gewitter, Sternenfeld,
Glühwürmchen, Neon-Emblem-SDC, Neon-Emblem-Bazzite,
Schwebende Blasen SDC und Schwebende Blasen Bazzite.
Die Motivlogik stammt aus dem Originalprojekt; Zeichnen und Texte wurden an
Canvas angepasst. Kleine Unterschiede bei Schrift und Darstellung sind möglich.

Einstellbar sind Geschwindigkeit, FPS, Renderauflösung, manuelle Pause,
Vollbild-Pause, eigene Logos für Neon und eigene Bilder hinter den Blasen.
Für Logos am besten ein PNG oder SVG mit transparentem Hintergrund verwenden.
Die Bildeinstellungen der gewählten Variante werden im Einstellungsdialog
angezeigt. Im Zufallsmodus lassen sich beide Varianten getrennt anpassen.

### Zufallsmodus

1. Bei **Motiv** den Eintrag **Zufällig (automatischer Wechsel)** auswählen.
2. Unter **Zufallswechsel alle (Minuten)** ein Intervall von **1 bis 30 Minuten**
   einstellen; voreingestellt sind **5 Minuten**.
3. **Anwenden** anklicken.

Der Modus startet sofort mit einem zufälligen Motiv und mischt alle neun
Motive pro Runde neu. Kein Motiv wird direkt zweimal nacheinander gezeigt.
Bei manueller Pause, Vollbild-Pause oder ausgeblendeter Vorschau hält auch der
Wechsel-Timer an. Beim Fortsetzen läuft die verbleibende Zeit weiter. Eine
Änderung des Intervalls startet die Wartezeit mit dem neuen Wert neu.
Um ein Motiv dauerhaft anzuzeigen, dieses wieder direkt auswählen.

| Motiv | Mitgeliefertes Standardbild unter `contents/web/assets/` |
| --- | --- |
| Neon-Emblem-SDC | Steam-Deck-Checker-Logo: `steam-deck-checker.png` |
| Neon-Emblem-Bazzite | Bazzite-Logo: `bazzite-logo.svg` |
| Schwebende Blasen SDC | Steam-Deck-Checker-Spielecollage: `steam-deck-checker-games.png` |
| Schwebende Blasen Bazzite | Bazzite-Wallpaper: `bazzite-wallpaper.png` |

Alle vier Standardbilder sind im Paket enthalten und funktionieren offline.
Über die jeweilige Bildauswahl kann ein eigenes Logo oder Hintergrundbild
gewählt werden. „Standardlogo“ bzw. „Standardbild“ stellt immer das
Standardbild dieser Variante wieder her. Die Abdunkelung der Bilder hinter
den Blasen bleibt einstellbar.

### Maus, Touchpad und Touchscreen

Alle neun Motive reagieren auf Zeigerbewegungen auf der freien
Desktopfläche. Mit dem Touchscreen den Finger aufsetzen und bewegen;
kurzes Antippen wird als Klick weitergereicht. Maus und Touchpad reagieren
auch ohne gedrückte Taste. Eingaben über anderen Fenstern werden unter
Wayland nicht global erfasst.

| Motiv | Reaktion |
| --- | --- |
| Matrix-Regen | Zeichen flackern und verändern sich entlang der Bewegung. |
| Code-Stream | Ein Lichtfeld folgt dem Zeiger, nahe Codezeilen werden langsamer. |
| Gewitter | Der Zeiger beeinflusst die Windrichtung und erzeugt eine helle Reflexion. |
| Sternenfeld | Die Flugrichtung und der Hintergrund folgen dem Zeiger. |
| Glühwürmchen | Tiere werden angezogen, ein Licht folgt dem Zeiger. |
| Neon-Emblem-SDC / Neon-Emblem-Bazzite | Leuchten, Funken und Klick-/Toucheffekte am Emblem. |
| Schwebende Blasen SDC / Schwebende Blasen Bazzite | Blasen werden vom Zeiger verdrängt. |

Maus- und Touchkontakte werden getrennt behandelt. Kurze Klicks werden bis
zum nächsten Animationsbild gepuffert; ein Abbruch oder eine Pause löscht
offene Eingaben.

Beim Ende einer Ziehbewegung wird die zuletzt erkannte Position verwendet.
Beim Wechsel zu einem anderen Hintergrundmodul werden die Beobachter entfernt.

Zum Einstieg: **24 FPS und 60 % Renderauflösung**. Für mehrere Bildschirme wird
das Modul je Bildschirm ausgewählt und konfiguriert. Die Vollbild-Pause gilt
für alle Bildschirme der aktuellen Aktivität und des aktuellen virtuellen
Desktops. Mausreaktionen werden auf der freien Desktopfläche weitergereicht;
Zeigerbewegungen über fremden Fenstern sind unter Wayland nicht global verfügbar.

Die GNOME-Menüleiste, GNOME-Übersicht und automatische Logo-Freistellung sind
nicht Teil dieser KDE-Version. Das Modul ist für den **Desktop-Modus** gedacht.

## Vorschau ohne Installation

`Vorschau.html` im Browser öffnen. Oben links lassen sich Motiv, Zufallsmodus
und Wechselintervall auswählen und die Animation pausieren. Die Vorschau prüft die Animationen, ersetzt aber
keinen Test innerhalb von Plasma.

## Prüfung von 0.3.2

Alle neun Motive wurden mit QtWebEngine 6.10.3 geladen und animiert. Bei den
vier SDC-/Bazzite-Varianten wurde auch geprüft, dass tatsächlich das richtige
Logo oder Hintergrundbild gezeichnet wird. Die mitgelieferten Bazzite-Dateien
sind unveränderte Kopien der bereitgestellten Originale.

Getestet wurden getrennte eigene Bilder und das Zurücksetzen aller vier
Standardbilder, Zeigereingaben, die Browser-Auswahl sowie jeweils fünf
vollständige Zufallsrunden im Webplayer und in der originalen QML-Rotation.
Der Einstellungsdialog wurde mit echten Qt-Controls und einem ersetzten
Kirigami-Layout geprüft: alle zehn Auswahlwerte einschließlich Zufallsmodus,
Änderungsmeldungen und die Zuordnung zum Konfigurationsschema.

## Prüfung der Basisversion 0.3.1

Für **0.3.1** wurden die Eingaben mit Qt Quick 6.10.3 und einer über dem
Hintergrund liegenden, Hover und Klicks annehmenden Desktop-Testfläche geprüft.
Die alte Eingabeversion empfängt in diesem Aufbau keine Zeigerereignisse;
die neue empfängt Mausbewegung, Drücken, Ziehen, Loslassen sowie Touchbewegung.
Klicks, Kontextmenü-Ereignisse und Zeigerbewegungen erreichen weiterhin die
Desktop-Testfläche. Auch die Koordinaten versetzter Hintergrundflächen und
das vollständige Entfernen der Beobachter beim Entladen wurden geprüft.

Ein Integrationstest lädt die produktive main.qml, den Webplayer und die
Animationen gemeinsam. Mausereignisse erreichen dessen JavaScript-Schnittstelle,
ein nativer Motivwechsel erreicht den tatsächlichen QtWebEngine-Renderer,
Intervalländerungen und Pause werden weitergereicht. Alle sieben Motive wurden
darin ohne Animationsfehler geladen. Nur die Plasma-Konfigurationsschnittstelle
und eine leere Fensterliste wurden für diesen Test ersetzt.

Der native Timer wurde mit **einer echten Minute Laufzeit** geprüft. Zusätzlich
wurden mehrere vollständige Runden, keine unmittelbaren Wiederholungen,
Intervalländerungen auf 1 und 30 Minuten, manueller Motivwechsel sowie
Pausieren und Fortsetzen getestet. Die längeren Runden wurden beschleunigt;
es wurde nicht für jedes Motiv ein vollständiger 30-Minuten-Test durchgeführt.

Die Konfigurationslogik wurde mit echten Qt-Controls geprüft: Intervalländerung
über Pfeile und Tastatur, Änderungsmeldungen und erneutes Laden gespeicherter
Werte. Für diesen Test wurden nur das Kirigami-Layout und seine Beschriftungen
durch ein Qt-Layout ersetzt. Ein vollständiger Bazzite-/Plasma-Desktop stand
für diese automatisierten Tests nicht zur Verfügung. Die anschließenden
Praxistests der Basisversion unter Bazzite wurden vom Anwender erfolgreich
durchgeführt.

Wenn das Modul nicht startet, bitte die Ausgabe von `bash install.sh` und die
Plasma-Version (`plasmashell --version`) weitergeben. Bei Problemen nach der
Auswahl lässt sich im Hintergrunddialog wieder ein anderes Modul auswählen.

## Entfernen

Zuerst für alle betroffenen Bildschirme und Aktivitäten ein anderes
Hintergrundbild auswählen. Im entpackten Ordner anschließend:

```bash
bash uninstall.sh
```

## Herkunft

Originalprojekt und Animationen: **ryth9419-jpg/livewallpaper**
https://github.com/ryth9419-jpg/livewallpaper

Verwendetes Archiv `live-background.zip`, Git-Blob:
`57f437a02ccb11c8282ecc3daacd48227b0fc34f` (Abruf am 05.11.2026).

Die Datei `engine.js` enthält die Motivlogik des Originalprojekts mit
angepasstem Backend und zusätzlichen Zeigerreaktionen. `adapter.js`,
`player.js`, `pointer.js`, `randomizer.js`, `ThemeRotation.qml`, die KDE-Oberfläche und die
Installationsskripte wurden für diese KDE-Version erstellt. Aus dem
Originalprojekt wird keine andere Lizenz abgeleitet oder zugesagt.

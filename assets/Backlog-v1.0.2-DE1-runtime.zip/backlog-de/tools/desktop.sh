#!/bin/sh
# Run by the "Install Backlog" and "Uninstall Backlog" launchers in the download folder (double-click them in
# Desktop Mode). Does the same as tools/install.sh and sync.py --uninstall, then says how it went in a pop-up
# (kdialog on SteamOS and other KDE desktops; plain text in the terminal window elsewhere).
here=$(cd "$(dirname "$0")" && pwd)

have_dialog() { command -v kdialog >/dev/null 2>&1; }
pause() { printf '\nZum Schließen die Eingabetaste drücken. '; read _ || true; }
tell() { # tell <msgbox|error> <text>
  if have_dialog; then kdialog --title "Backlog" "--$1" "$2" >/dev/null 2>&1 || true; else printf '\n%s\n' "$2"; pause; fi
}

case "$1" in
  install)
    # Three questions first (pop-ups on SteamOS and other KDE desktops). Cancel any one and that setting is left
    # as it is: the defaults on a first install, your own choice on a later one.
    scenes=""; minutes=""; clock=""
    if have_dialog; then
      picked=$(kdialog --title "Backlog" --separate-output --checklist "Welche Szenen sollen angezeigt werden? Tippe eine Szene an, um sie ein- oder auszuschalten." \
        mosaic "Mosaik: Deine Cover bilden das Bild eines Spiels" on \
        drift "Drift: Eine geneigte Wand aus Covern gleitet vorbei" on \
        flip "Flip: Cover klappen wie eine Anzeigetafel um" on \
        ripple "Wellen: Eine langsame Welle bewegt sich durch die Cover" on 2>/dev/null) || picked=""
      scenes=$(printf '%s\n' "$picked" | tr -d '"' | tr -s ' \n' ',' | sed 's/^,//; s/,$//')
      minutes=$(kdialog --title "Backlog" --radiolist "Wie lange soll jede Szene angezeigt werden?" \
        1 "1 Minute" off 3 "3 Minuten" off 5 "5 Minuten" on 10 "10 Minuten" off 15 "15 Minuten" off 30 "30 Minuten" off 2>/dev/null) || minutes=""
      minutes=$(printf '%s' "$minutes" | tr -d '" \n')
      clock=$(kdialog --title "Backlog" --radiolist "Was soll in der Bildschirmecke angezeigt werden?" \
        all "Uhrzeit, Datum, Spieleanzahl und gesamte Spielzeit" on \
        clock "Nur Uhrzeit und Datum" off \
        none "Nichts" off 2>/dev/null) || clock=""
      clock=$(printf '%s' "$clock" | tr -d '" \n')
    fi
    set --
    if [ -n "$scenes" ]; then set -- "$@" --scenes "$scenes"; fi
    if [ -n "$minutes" ]; then set -- "$@" --minutes "$minutes"; fi
    if [ -n "$clock" ]; then set -- "$@" --clock "$clock"; fi
    if sh "$here/install.sh" "$@"; then
      tell msgbox "Backlog ist installiert.

Wechsle zurück in den Spielmodus. Öffne Einstellungen > Anpassung > Bildschirmschoner und wähle backlog.

Deine Spiele, Spielstunden und Erfolge werden automatisch aktualisiert. Du kannst diesen Download-Ordner jetzt löschen."
    else
      echo
      echo "Die Installation wurde nicht abgeschlossen. Die Meldungen oben zeigen den Fehler."
      if have_dialog; then kdialog --title "Backlog" --error "Die Installation wurde nicht abgeschlossen. Im Terminalfenster dahinter steht die Fehlermeldung." >/dev/null 2>&1 || true; fi
      pause
      exit 1
    fi
    ;;
  uninstall)
    if have_dialog; then
      kdialog --title "Backlog" --yesno "Backlog aus Steam entfernen und die automatische Aktualisierung ausschalten?" >/dev/null 2>&1 || exit 0
    else
      printf 'Backlog aus Steam entfernen und die automatische Aktualisierung ausschalten? [j/N] '; read answer || answer=n
      case "$answer" in j|J|ja|JA|Ja|y|Y|yes|YES) ;; *) exit 0 ;; esac
    fi
    if ! command -v python3 >/dev/null 2>&1; then tell error "Python 3 wurde nicht gefunden. Es wurde nichts entfernt."; exit 1; fi
    if python3 "$here/sync.py" --uninstall; then
      tell msgbox "Backlog wurde entfernt.

Falls Backlog dein Bildschirmschoner war, wähle unter Einstellungen > Anpassung > Bildschirmschoner einen anderen aus."
    else
      echo
      echo "Die Deinstallation wurde nicht abgeschlossen. Die Meldungen oben zeigen den Fehler."
      if have_dialog; then kdialog --title "Backlog" --error "Die Deinstallation wurde nicht abgeschlossen. Im Terminalfenster dahinter steht die Fehlermeldung." >/dev/null 2>&1 || true; fi
      pause
      exit 1
    fi
    ;;
  *)
    echo "Aufruf: sh tools/desktop.sh install|uninstall" >&2
    exit 2
    ;;
esac

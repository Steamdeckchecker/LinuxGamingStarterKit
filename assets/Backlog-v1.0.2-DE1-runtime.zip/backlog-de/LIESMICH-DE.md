# Backlog 1.0.2 – Deutsche Version DE1

Inoffizielle deutsche Übersetzung des Bildschirmschoners von Glidian.
Grundlage: https://github.com/glidiandev/backlog/releases/tag/v1.0.2
Original-Commit: `0690aa170b589ff69e3f0b678d8b7a325489c8dd`
Stand der Übersetzung: 19. November 2026.

## Was ist auf Deutsch?

- Datum mit deutschen Wochentagen und Monaten, zum Beispiel „Donnerstag, 19. November 2026“.
- Spielanzahl und Spielstunden, einschließlich Dezimalkomma und Tausenderpunkt.
- Angaben wie „2,5 Stunden, Zuletzt gespielt: vor 3 Tagen“ und „In deiner Bibliothek“.
- Erfolge und vollständig freigeschaltete Erfolge.
- Spotlight- und Rangbeschriftungen in allen Szenen, auch im optionalen Ripple 2.
- Installations- und Deinstallationsdialoge auf KDE/Steam Deck sowie die Namen der Starter.
- Neue Installationen verwenden standardmäßig die 24-Stunden-Uhr.

Deutsche Groß- und Kleinschreibung bleibt in den Spielzeitangaben erhalten.
Längere Beschriftungen dürfen umbrechen. Spielnamen und Cover stammen weiterhin aus Steam.
Die technischen Terminalmeldungen der Synchronisationsprogramme und die ursprüngliche
Dokumentation sind weiterhin auf Englisch.

## Steam Deck / SteamOS / Bazzite mit KDE

1. In den Desktop-Modus wechseln und die ZIP-Datei vollständig entpacken.
2. Im entpackten Ordner `backlog-de` die Datei **Install Backlog.desktop** doppelklicken.
   Je nach Dateimanager wird sie als **Backlog installieren** angezeigt.
   Falls nachgefragt wird, die Ausführung des Starters bestätigen.
3. Szenen, Dauer und Umfang der Uhranzeige auswählen.
4. In den Spielmodus zurückkehren und unter **Einstellungen > Anpassung > Bildschirmschoner**
   den Eintrag **backlog** auswählen. Falls er fehlt, Steam neu starten.

Alternativ im entpackten Ordner ein Terminal öffnen und ausführen:

```sh
sh tools/install.sh
```

Python 3 wird benötigt; unter SteamOS ist es normalerweise bereits vorhanden.
Es ist kein Kompilieren erforderlich. Die automatische Aktualisierung der lokalen
Spieledaten funktioniert wie im Original.

## Bereits installiert?

Die deutsche Version einfach erneut installieren. Der vorhandene Bildschirmschoner
`backlog` wird aktualisiert; eine vorherige Deinstallation ist nicht nötig.
Die vorhandene `config.js` bleibt erhalten. Im grafischen Installer gewählte Szenen,
Laufzeiten und Uhranzeigen werden wie im Original übernommen.

Wenn deine bisherige Konfiguration `hour12: true` enthält, wird diese Einstellung
beibehalten; die Tageshälften erscheinen dann als „vorm.“ und „nachm.“.
Für eine 24-Stunden-Uhr in der installierten `config.js` den Wert auf
`hour12: false` ändern. Anschließend den Bildschirmschoner neu öffnen.

Der installierte Ordner liegt unter:

```text
<Steam>/config/uioverrides/screensavers/backlog/
```

Bei einer späteren Installation einer unveränderten Originalversion werden die
deutschen Anzeigetexte wieder durch deren englische Texte ersetzt.

## Windows / Steam Big Picture

Im entpackten Ordner PowerShell öffnen und ausführen:

```powershell
powershell -ExecutionPolicy Bypass -File tools\sync.ps1 -Install
```

Danach in Steam Big Picture **Einstellungen > Anpassung > Bildschirmschoner > backlog**
auswählen. Falls nötig, Steam neu starten. Die Bildschirmschoner-Texte sind auch unter
Windows auf Deutsch; das Synchronisationsskript verwendet seine ursprünglichen Meldungen.

## Entfernen

Auf dem Steam Deck **Uninstall Backlog.desktop** / **Backlog deinstallieren** starten.
Das entfernt den Bildschirmschoner und schaltet die automatische Aktualisierung aus.
Weitere Hinweise, insbesondere für Windows: `README.md` und `tools/README.md`.

## Prüfung und Lizenz

JavaScript- und Shell-Syntax sowie die deutschen Text- und Datumsfunktionen wurden
technisch geprüft. Die Übernahme vorhandener Einstellungen wurde mit einem temporären
Installationsordner geprüft. Ein visueller Browser-Test und ein Test im Steam-Spielmodus
auf echter Hardware waren hier nicht möglich.

Originalprojekt von Glidian: https://github.com/glidiandev/backlog
MIT-Lizenz: siehe `LICENSE`. Die beigefügten Schriftlizenzen bleiben erhalten.
